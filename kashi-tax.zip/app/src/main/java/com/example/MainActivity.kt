package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.ContactPhone
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.BusinessCenter
import androidx.compose.material.icons.outlined.ContactPhone
import androidx.compose.material.icons.outlined.FolderShared
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.components.SubmissionConfirmationDialog
import com.example.ui.navigation.KashiNavRoutes
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.ContactUsScreen
import com.example.ui.screens.CustomerDocumentsScreen
import com.example.ui.screens.GovernmentDocumentsScreen
import com.example.ui.screens.GstServicesHubScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ItrServicesScreen
import com.example.ui.screens.NewGstRegistrationScreen
import com.example.ui.screens.OnlineFormsScreen
import com.example.ui.screens.ServicesCatalogScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.KashiTaxTheme
import com.example.ui.viewmodel.CustomerDocumentsViewModel
import com.example.ui.viewmodel.KashiTaxViewModel
import com.example.util.NotificationHelper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        NotificationHelper.ensureChannel(this)

        setContent {
            KashiTaxTheme {
                val appViewModel: KashiTaxViewModel = viewModel(
                    factory = KashiTaxViewModel.factory(application)
                )
                val customerDocsViewModel: CustomerDocumentsViewModel = viewModel(
                    factory = CustomerDocumentsViewModel.factory(application)
                )
                KashiTaxApp(
                    viewModel = appViewModel,
                    customerDocsViewModel = customerDocsViewModel
                )
            }
        }
    }
}

private data class TopLevelDestination(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val topLevelDestinations = listOf(
    TopLevelDestination(
        route = KashiNavRoutes.HOME,
        label = "Home",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home,
        testTag = "nav_tab_home"
    ),
    TopLevelDestination(
        route = KashiNavRoutes.SERVICES,
        label = "Services",
        selectedIcon = Icons.Filled.BusinessCenter,
        unselectedIcon = Icons.Outlined.BusinessCenter,
        testTag = "nav_tab_services"
    ),
    TopLevelDestination(
        route = KashiNavRoutes.MY_DOCUMENTS,
        label = "Documents",
        selectedIcon = Icons.Filled.FolderShared,
        unselectedIcon = Icons.Outlined.FolderShared,
        testTag = "nav_tab_documents"
    ),
    TopLevelDestination(
        route = KashiNavRoutes.CONTACT,
        label = "Contact",
        selectedIcon = Icons.Filled.ContactPhone,
        unselectedIcon = Icons.Outlined.ContactPhone,
        testTag = "nav_tab_contact"
    )
)

@Composable
private fun KashiTaxApp(
    viewModel: KashiTaxViewModel,
    customerDocsViewModel: CustomerDocumentsViewModel
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route.orEmpty()

    val enquiries by viewModel.enquiries.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadCount.collectAsStateWithLifecycle()
    val adminAuthState by viewModel.adminAuthState.collectAsStateWithLifecycle()
    val adminAuthError by viewModel.adminAuthError.collectAsStateWithLifecycle()
    val isSyncingCloud by viewModel.isSyncingCloud.collectAsStateWithLifecycle()
    val syncFeedback by viewModel.syncFeedback.collectAsStateWithLifecycle()
    val submissionConfirmation by viewModel.submissionConfirmation.collectAsStateWithLifecycle()

    val customerSession by customerDocsViewModel.session.collectAsStateWithLifecycle()
    val customerDocuments by customerDocsViewModel.documents.collectAsStateWithLifecycle()
    val isDocsLoading by customerDocsViewModel.isLoading.collectAsStateWithLifecycle()
    val isDocsUploading by customerDocsViewModel.isUploading.collectAsStateWithLifecycle()
    val isDocsAuthBusy by customerDocsViewModel.isAuthBusy.collectAsStateWithLifecycle()
    val docsErrorMessage by customerDocsViewModel.errorMessage.collectAsStateWithLifecycle()
    val docsStatusMessage by customerDocsViewModel.statusMessage.collectAsStateWithLifecycle()

    val activityContext = androidx.compose.ui.platform.LocalContext.current

    val showTopLevelChrome = currentRoute == KashiNavRoutes.HOME ||
        currentRoute == KashiNavRoutes.SERVICES ||
        currentRoute == KashiNavRoutes.MY_DOCUMENTS ||
        currentRoute.startsWith(KashiNavRoutes.CONTACT)

    fun navigateTopLevel(route: String) {
        val target = if (route == KashiNavRoutes.CONTACT) KashiNavRoutes.contactWithService("") else route
        navController.navigate(target) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun isSelectedDestination(destRoute: String): Boolean {
        return if (destRoute == KashiNavRoutes.CONTACT) {
            currentRoute.startsWith(KashiNavRoutes.CONTACT)
        } else {
            currentRoute == destRoute
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (showTopLevelChrome && !useNavRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                        tonalElevation = 2.dp
                    ) {
                        topLevelDestinations.forEach { dest ->
                            val selected = isSelectedDestination(dest.route)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopLevel(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = { Text(dest.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.secondaryContainer,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showTopLevelChrome && useNavRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
                    ) {
                        topLevelDestinations.forEach { dest ->
                            val selected = isSelectedDestination(dest.route)
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopLevel(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = { Text(dest.label) },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    NavHost(
                        navController = navController,
                        startDestination = KashiNavRoutes.SPLASH
                    ) {
                        composable(KashiNavRoutes.SPLASH) {
                            SplashScreen(
                                onEnterApp = {
                                    navController.navigate(KashiNavRoutes.HOME) {
                                        popUpTo(KashiNavRoutes.SPLASH) { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable(KashiNavRoutes.HOME) {
                            HomeScreen(
                                unreadCount = unreadCount,
                                onOpenGstRegistration = {
                                    navController.navigate(KashiNavRoutes.GST_SERVICES_HUB)
                                },
                                onOpenItrServices = {
                                    navController.navigate(KashiNavRoutes.ITR_SERVICES)
                                },
                                onOpenGovernmentDocuments = {
                                    navController.navigate(KashiNavRoutes.GOVERNMENT_DOCUMENTS)
                                },
                                onOpenOnlineForms = {
                                    navController.navigate(KashiNavRoutes.ONLINE_FORMS)
                                },
                                onOpenMyDocuments = {
                                    navigateTopLevel(KashiNavRoutes.MY_DOCUMENTS)
                                },
                                onOpenAllServices = {
                                    navigateTopLevel(KashiNavRoutes.SERVICES)
                                },
                                onOpenContactUs = { preselected ->
                                    navController.navigate(
                                        KashiNavRoutes.contactWithService(preselected.orEmpty())
                                    )
                                },
                                onOpenAdminPortal = {
                                    navController.navigate(KashiNavRoutes.ADMIN) {
                                        launchSingleTop = true
                                    }
                                },
                                onQuickCallbackSubmit = { name, phone ->
                                    viewModel.submitContactEnquiry(
                                        customerName = name,
                                        mobileNumber = phone,
                                        serviceName = "2-Hour Advisor Callback",
                                        message = "Requested a quick advisor callback from the Home screen.",
                                        serviceCategory = "General Enquiry"
                                    )
                                }
                            )
                        }

                        composable(KashiNavRoutes.SERVICES) {
                            ServicesCatalogScreen(
                                onInquireService = { serviceTitle ->
                                    navController.navigate(
                                        KashiNavRoutes.contactWithService(serviceTitle)
                                    )
                                },
                                onOpenGstRegistration = {
                                    navController.navigate(KashiNavRoutes.GST_REGISTRATION)
                                },
                                onOpenGovernmentDocuments = {
                                    navController.navigate(KashiNavRoutes.GOVERNMENT_DOCUMENTS)
                                },
                                onOpenOnlineForms = {
                                    navController.navigate(KashiNavRoutes.ONLINE_FORMS)
                                }
                            )
                        }

                        composable(KashiNavRoutes.MY_DOCUMENTS) {
                            CustomerDocumentsScreen(
                                isSupabaseConfigured = customerDocsViewModel.isSupabaseConfigured,
                                session = customerSession,
                                documents = customerDocuments,
                                isLoading = isDocsLoading,
                                isUploading = isDocsUploading,
                                isAuthBusy = isDocsAuthBusy,
                                errorMessage = docsErrorMessage,
                                statusMessage = docsStatusMessage,
                                onSignIn = customerDocsViewModel::signIn,
                                onSignUp = customerDocsViewModel::signUp,
                                onSignOut = customerDocsViewModel::signOut,
                                onRefresh = customerDocsViewModel::refreshDocuments,
                                onUploadUris = customerDocsViewModel::uploadUris,
                                onUploadCameraPhoto = customerDocsViewModel::uploadCameraPhoto,
                                onViewDocument = { doc ->
                                    customerDocsViewModel.viewDocument(activityContext, doc)
                                },
                                onDownloadDocument = customerDocsViewModel::downloadDocument,
                                onDeleteDocument = customerDocsViewModel::deleteDocument,
                                onClearMessages = customerDocsViewModel::clearMessages
                            )
                        }

                        composable(
                            route = KashiNavRoutes.CONTACT_PATTERN,
                            arguments = listOf(
                                navArgument("service") {
                                    type = NavType.StringType
                                    defaultValue = ""
                                }
                            )
                        ) { entry ->
                            val preselected = entry.arguments?.getString("service").orEmpty()
                            ContactUsScreen(
                                preselectedService = preselected.takeIf { it.isNotBlank() },
                                onSubmitRequest = { name, mobile, service, message, attachments ->
                                    viewModel.submitContactEnquiry(
                                        customerName = name,
                                        mobileNumber = mobile,
                                        serviceName = service,
                                        message = message,
                                        attachedDocuments = attachments
                                    )
                                }
                            )
                        }

                        composable(KashiNavRoutes.ADMIN) {
                            AdminScreen(
                                authState = adminAuthState,
                                authError = adminAuthError,
                                enquiries = enquiries,
                                isSupabaseConfigured = viewModel.isSupabaseConfigured,
                                isSyncingCloud = isSyncingCloud,
                                syncFeedback = syncFeedback,
                                onBack = { navController.popBackStack() },
                                onSetupAdmin = viewModel::setupAdminAccount,
                                onLoginAdmin = viewModel::loginAdmin,
                                onLogoutAdmin = viewModel::logoutAdmin,
                                onClearError = viewModel::clearAdminError,
                                onSyncCloud = viewModel::syncCloudEnquiries,
                                onOpenAttachment = { attachment ->
                                    viewModel.openAttachment(activityContext, attachment)
                                },
                                onToggleStatus = viewModel::toggleEnquiryStatus,
                                onDeleteEnquiry = viewModel::deleteEnquiry,
                                onMarkAllRead = viewModel::markAllEnquiriesRead
                            )
                        }

                        composable(KashiNavRoutes.GST_SERVICES_HUB) {
                            GstServicesHubScreen(
                                onBack = { navController.popBackStack() },
                                onOpenNewGstRegistration = {
                                    navController.navigate(KashiNavRoutes.GST_REGISTRATION)
                                },
                                onInquireGstService = { service ->
                                    navController.navigate(KashiNavRoutes.contactWithService(service))
                                }
                            )
                        }

                        composable(KashiNavRoutes.GST_REGISTRATION) {
                            NewGstRegistrationScreen(
                                onBack = { navController.popBackStack() },
                                onSubmitApplication = { name, phone, notes, docs, mode, proof ->
                                    viewModel.submitGstRegistration(
                                        customerName = name,
                                        mobileNumber = phone,
                                        notes = notes,
                                        attachedDocuments = docs,
                                        paymentMode = mode,
                                        paymentProof = proof
                                    )
                                }
                            )
                        }

                        composable(KashiNavRoutes.ITR_SERVICES) {
                            ItrServicesScreen(
                                onBack = { navController.popBackStack() },
                                onSelectItrAction = { service ->
                                    navController.navigate(KashiNavRoutes.contactWithService(service))
                                }
                            )
                        }

                        composable(KashiNavRoutes.GOVERNMENT_DOCUMENTS) {
                            GovernmentDocumentsScreen(
                                onBack = { navController.popBackStack() },
                                onApplyDocument = { docTitle ->
                                    navController.navigate(KashiNavRoutes.contactWithService(docTitle))
                                }
                            )
                        }

                        composable(KashiNavRoutes.ONLINE_FORMS) {
                            OnlineFormsScreen(
                                onBack = { navController.popBackStack() },
                                onSubmitFormRequest = { name, phone, title, notes, docs ->
                                    viewModel.submitOnlineFormRequest(
                                        customerName = name,
                                        mobileNumber = phone,
                                        formTitle = title,
                                        notes = notes,
                                        attachedDocuments = docs
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    submissionConfirmation?.let { confirmation ->
        SubmissionConfirmationDialog(
            confirmation = confirmation,
            onDismiss = viewModel::clearSubmissionConfirmation
        )
    }
}
