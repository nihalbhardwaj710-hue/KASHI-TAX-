package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest

private val Context.adminDataStore by preferencesDataStore(name = "kashi_admin_prefs")

data class AdminAuthSnapshot(
    val isConfigured: Boolean = false,
    val isLoggedIn: Boolean = false,
    val adminEmail: String = "",
    val supabaseAccessToken: String = ""
)

class AdminPreferences(private val context: Context) {

    private object Keys {
        val ADMIN_EMAIL = stringPreferencesKey("admin_email")
        val PASSWORD_HASH = stringPreferencesKey("admin_password_hash")
        val IS_LOGGED_IN = booleanPreferencesKey("admin_is_logged_in")
        val SUPABASE_ACCESS_TOKEN = stringPreferencesKey("supabase_access_token")
    }

    val authStateFlow: Flow<AdminAuthSnapshot> = context.adminDataStore.data.map { prefs ->
        val email = prefs[Keys.ADMIN_EMAIL].orEmpty()
        val hash = prefs[Keys.PASSWORD_HASH].orEmpty()
        val loggedIn = prefs[Keys.IS_LOGGED_IN] ?: false
        val token = prefs[Keys.SUPABASE_ACCESS_TOKEN].orEmpty()
        AdminAuthSnapshot(
            isConfigured = email.isNotBlank() && (hash.isNotBlank() || token.isNotBlank()),
            isLoggedIn = loggedIn && email.isNotBlank(),
            adminEmail = email,
            supabaseAccessToken = token
        )
    }

    suspend fun setupAdminAccount(email: String, password: String) {
        val normalizedEmail = email.trim().lowercase()
        val hash = sha256("$normalizedEmail::${password.trim()}")
        context.adminDataStore.edit { prefs ->
            prefs[Keys.ADMIN_EMAIL] = normalizedEmail
            prefs[Keys.PASSWORD_HASH] = hash
            prefs[Keys.IS_LOGGED_IN] = true
        }
    }

    suspend fun verifyAndLoginLocal(email: String, password: String): Boolean {
        val prefs = context.adminDataStore.data.first()
        val savedEmail = prefs[Keys.ADMIN_EMAIL].orEmpty()
        val savedHash = prefs[Keys.PASSWORD_HASH].orEmpty()
        if (savedEmail.isBlank() || savedHash.isBlank()) return false

        val candidateEmail = email.trim().lowercase()
        val candidateHash = sha256("$candidateEmail::${password.trim()}")
        val matched = candidateEmail == savedEmail && candidateHash == savedHash
        if (matched) {
            context.adminDataStore.edit { it[Keys.IS_LOGGED_IN] = true }
        }
        return matched
    }

    suspend fun saveSupabaseSession(email: String, accessToken: String) {
        context.adminDataStore.edit { prefs ->
            prefs[Keys.ADMIN_EMAIL] = email.trim().lowercase()
            prefs[Keys.SUPABASE_ACCESS_TOKEN] = accessToken
            prefs[Keys.IS_LOGGED_IN] = true
        }
    }

    suspend fun getSupabaseAccessToken(): String {
        return context.adminDataStore.data.first()[Keys.SUPABASE_ACCESS_TOKEN].orEmpty()
    }

    suspend fun logout() {
        context.adminDataStore.edit { prefs ->
            prefs[Keys.IS_LOGGED_IN] = false
            prefs[Keys.SUPABASE_ACCESS_TOKEN] = ""
        }
    }

    private fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
