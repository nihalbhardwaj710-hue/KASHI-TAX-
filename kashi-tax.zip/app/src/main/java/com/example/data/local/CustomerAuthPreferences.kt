package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.customerAuthDataStore by preferencesDataStore(name = "kashi_customer_auth_prefs")

data class CustomerAuthSession(
    val userId: String = "",
    val email: String = "",
    val accessToken: String = "",
    val refreshToken: String = ""
) {
    val isAuthenticated: Boolean
        get() = userId.isNotBlank() && accessToken.isNotBlank()
}

class CustomerAuthPreferences(private val context: Context) {

    private object Keys {
        val USER_ID = stringPreferencesKey("customer_user_id")
        val EMAIL = stringPreferencesKey("customer_email")
        val ACCESS_TOKEN = stringPreferencesKey("customer_access_token")
        val REFRESH_TOKEN = stringPreferencesKey("customer_refresh_token")
    }

    val sessionFlow: Flow<CustomerAuthSession> = context.customerAuthDataStore.data.map { prefs ->
        CustomerAuthSession(
            userId = prefs[Keys.USER_ID].orEmpty(),
            email = prefs[Keys.EMAIL].orEmpty(),
            accessToken = prefs[Keys.ACCESS_TOKEN].orEmpty(),
            refreshToken = prefs[Keys.REFRESH_TOKEN].orEmpty()
        )
    }

    suspend fun getCurrentSession(): CustomerAuthSession = sessionFlow.first()

    suspend fun saveSession(
        userId: String,
        email: String,
        accessToken: String,
        refreshToken: String
    ) {
        context.customerAuthDataStore.edit { prefs ->
            prefs[Keys.USER_ID] = userId
            prefs[Keys.EMAIL] = email.trim().lowercase()
            prefs[Keys.ACCESS_TOKEN] = accessToken
            prefs[Keys.REFRESH_TOKEN] = refreshToken
        }
    }

    suspend fun clearSession() {
        context.customerAuthDataStore.edit { prefs ->
            prefs.remove(Keys.USER_ID)
            prefs.remove(Keys.EMAIL)
            prefs.remove(Keys.ACCESS_TOKEN)
            prefs.remove(Keys.REFRESH_TOKEN)
        }
    }
}
