package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EnquiryDao {

    @Query("SELECT * FROM enquiries ORDER BY createdAtMillis DESC")
    fun observeAllEnquiries(): Flow<List<EnquiryEntity>>

    @Query("SELECT COUNT(*) FROM enquiries WHERE isReadByAdmin = 0")
    fun observeUnreadCount(): Flow<Int>

    @Query("SELECT * FROM enquiries WHERE referenceCode = :referenceCode LIMIT 1")
    suspend fun findByReferenceCode(referenceCode: String): EnquiryEntity?

    @Query("SELECT * FROM enquiries WHERE id = :id LIMIT 1")
    suspend fun findById(id: Long): EnquiryEntity?

    @Query("SELECT * FROM enquiries WHERE isSyncedToCloud = 0")
    suspend fun getUnsyncedEnquiries(): List<EnquiryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEnquiry(enquiry: EnquiryEntity): Long

    @Query("UPDATE enquiries SET remoteId = :remoteId, isSyncedToCloud = 1 WHERE id = :id")
    suspend fun markSynced(id: Long, remoteId: String)

    @Query("UPDATE enquiries SET status = :status, isReadByAdmin = 1 WHERE id = :id")
    suspend fun updateEnquiryStatus(id: Long, status: String)

    @Query("UPDATE enquiries SET isReadByAdmin = 1 WHERE isReadByAdmin = 0")
    suspend fun markAllReadByAdmin()

    @Query("DELETE FROM enquiries WHERE id = :id")
    suspend fun deleteEnquiryById(id: Long)
}
