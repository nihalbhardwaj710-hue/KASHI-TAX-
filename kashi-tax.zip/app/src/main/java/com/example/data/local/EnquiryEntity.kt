package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

object EnquiryStatus {
    const val PENDING = "PENDING"
    const val COMPLETED = "COMPLETED"
}

object EnquiryPriority {
    const val STANDARD = "STANDARD"
    const val URGENT = "URGENT"
}

object PaymentMode {
    const val NONE = "NONE"
    const val PAY_ADVANCE = "PAY_ADVANCE"
    const val PAY_AFTER_WORK = "PAY_AFTER_WORK"
}

@Entity(
    tableName = "enquiries",
    indices = [Index(value = ["referenceCode"], unique = true)]
)
data class EnquiryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val remoteId: String? = null,
    val referenceCode: String,
    val customerName: String,
    val mobileNumber: String,
    val serviceCategory: String,
    val serviceName: String,
    val message: String,
    val attachedDocuments: String = "",
    val paymentMode: String = PaymentMode.NONE,
    val paymentProofName: String = "",
    val status: String = EnquiryStatus.PENDING,
    val priority: String = EnquiryPriority.STANDARD,
    val isReadByAdmin: Boolean = false,
    val isSyncedToCloud: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis()
)
