package com.example.data.model

object BusinessContact {
    const val BRAND_NAME = "Kashi Tax & Business Services"
    const val SHORT_NAME = "Kashi Tax"
    const val OFFICE_ADDRESS = "Harishchandra PG College, Kashi Library, Jakhania, Ghazipur, Uttar Pradesh 275203"
    const val SHORT_ADDRESS = "Harishchandra PG College, Jakhania, Ghazipur, UP 275203"
    const val EMAIL = "kashitaxservices@gmail.com"
    const val PHONE_DISPLAY = "+91 98765 43210"
    const val PHONE_DIAL = "+919876543210"
    const val WHATSAPP_NUMBER = "919876543210"
    const val HOURS = "Mon – Sat: 9:30 AM – 7:30 PM"
    const val UPI_ID = "kashitaxservices@upi"
    const val MAPS_QUERY = "Harishchandra PG College, Jakhania, Ghazipur, Uttar Pradesh 275203"
}

enum class ServiceCategory(val label: String) {
    ALL("All"),
    GST("GST Services"),
    ITR("ITR & Accounts"),
    ROC("ROC & Corporate"),
    GOVT_DOCS("Govt Documents"),
    ONLINE_FORMS("Online Forms")
}

data class ServiceCatalogItem(
    val id: String,
    val title: String,
    val category: ServiceCategory,
    val summary: String,
    val feeLabel: String,
    val turnaroundTime: String,
    val requiredDocs: List<String>,
    val tag: String? = null
)

enum class GovtDocCategory(val label: String) {
    ALL("All Documents"),
    IDENTITY("Identity Proofs"),
    CERTIFICATES("Certificates"),
    ESSENTIALS("Other Essentials")
}

data class GovtDocumentService(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: GovtDocCategory,
    val turnaroundTime: String,
    val feeHint: String,
    val docsNeeded: String
)

data class ItrActionItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val feeLabel: String,
    val turnaroundTime: String
)

object CatalogData {

    val gstMandatoryDocuments: List<String> = listOf(
        "PAN Card (Proprietor / Business)",
        "Aadhaar Card (Linked with Mobile)",
        "Active Mobile Number & Email ID",
        "Bank Details (Passbook Front Page / Cancelled Cheque)",
        "Shop / Business Address Proof (Rent Agreement / Electricity Bill / Affidavit)"
    )

    val itrRequiredDocuments: List<String> = listOf(
        "PAN Card & Aadhaar Card",
        "Form 16 (Salaried) or Business Income Summary",
        "Bank Account Statement (April – March)",
        "Investment & Deduction Proofs (80C, 80D, LIC, Tuition)"
    )

    val itrActionItems: List<ItrActionItem> = listOf(
        ItrActionItem(
            id = "itr_new",
            title = "File New ITR",
            subtitle = "ITR-1, ITR-2, ITR-3 & ITR-4 filing for salaried individuals, traders, and professionals.",
            feeLabel = "Starts ₹599",
            turnaroundTime = "Same Day"
        ),
        ItrActionItem(
            id = "itr_revise",
            title = "Revise / Correct ITR",
            subtitle = "Fix errors, unclaimed deductions, or bank details in an already submitted return.",
            feeLabel = "Starts ₹799",
            turnaroundTime = "24 Hours"
        ),
        ItrActionItem(
            id = "itr_refund",
            title = "Check Refund Status",
            subtitle = "Track pending TDS / Income Tax refunds and resolve bank re-validation issues.",
            feeLabel = "₹199",
            turnaroundTime = "2 Hours"
        ),
        ItrActionItem(
            id = "itr_notice",
            title = "Reply to Tax Notice",
            subtitle = "Professional drafting and online submission for Section 143(1), 139(9) & demand notices.",
            feeLabel = "Starts ₹1,499",
            turnaroundTime = "24–48 Hours"
        )
    )

    val onlineFormSuggestions: List<String> = listOf(
        "UP Police Constable",
        "Army Agniveer",
        "SSC GD / CGL",
        "UP Scholarship Form",
        "College Admission Form",
        "Railway RRB / Group D",
        "PAN Card Correction"
    )

    val serviceCatalog: List<ServiceCatalogItem> = listOf(
        ServiceCatalogItem(
            id = "gst_reg",
            title = "GST Registration",
            category = ServiceCategory.GST,
            summary = "Complete GSTIN enrollment for proprietorship, partnership, or firm with ARN & certificate.",
            feeLabel = "₹999",
            turnaroundTime = "3–7 Working Days",
            requiredDocs = listOf("PAN Card", "Aadhaar Card", "Bank Proof", "Electricity Bill / Rent Agreement"),
            tag = "Most Popular"
        ),
        ServiceCatalogItem(
            id = "gst_return",
            title = "GST Return Filing (GSTR-1, 3B, 9)",
            category = ServiceCategory.GST,
            summary = "Timely monthly/quarterly GSTR-1, GSTR-3B, ITC reconciliation, and Annual GSTR-9 filing.",
            feeLabel = "₹499 / mo",
            turnaroundTime = "24 Hours",
            requiredDocs = listOf("Sales Invoices", "Purchase Bills", "GST Portal Credentials")
        ),
        ServiceCatalogItem(
            id = "gst_amend",
            title = "GST Amendment & Cancellation",
            category = ServiceCategory.GST,
            summary = "Update business address, bank account, trade name, or apply for voluntary GST surrender.",
            feeLabel = "₹799",
            turnaroundTime = "2–5 Working Days",
            requiredDocs = listOf("GSTIN Login", "Updated Address / Bank Proof")
        ),
        ServiceCatalogItem(
            id = "itr_filing",
            title = "ITR Filing (Salaried & Business)",
            category = ServiceCategory.ITR,
            summary = "Accurate Income Tax Return computation and e-verification with maximum eligible deductions.",
            feeLabel = "Starts ₹599",
            turnaroundTime = "Same Day",
            requiredDocs = listOf("PAN & Aadhaar", "Form 16 / Income Data", "Bank Statement"),
            tag = "Fast Track"
        ),
        ServiceCatalogItem(
            id = "balance_sheet",
            title = "Balance Sheet & Profit & Loss",
            category = ServiceCategory.ITR,
            summary = "Certified Balance Sheet, P&L statement, and CMA report for bank loans, tenders & tax audits.",
            feeLabel = "₹1,499",
            turnaroundTime = "24–48 Hours",
            requiredDocs = listOf("12-Month Bank Statement", "Sales/Purchase Summary", "Loan Details")
        ),
        ServiceCatalogItem(
            id = "roc_annual",
            title = "ROC AOC-4 & MGT-7 Filing",
            category = ServiceCategory.ROC,
            summary = "Annual statutory MCA compliance filing for Private Limited Companies and LLPs.",
            feeLabel = "₹2,999 + Govt Fee",
            turnaroundTime = "3–5 Working Days",
            requiredDocs = listOf("Audited Financials", "Board Report", "Director DSC")
        ),
        ServiceCatalogItem(
            id = "roc_company",
            title = "Company Incorporation & Dir-3 KYC",
            category = ServiceCategory.ROC,
            summary = "Pvt Ltd / OPC / LLP registration, MSME Udyam certificate, and annual Director KYC.",
            feeLabel = "Starts ₹999",
            turnaroundTime = "1–7 Working Days",
            requiredDocs = listOf("Directors PAN & Aadhaar", "Registered Office Proof", "DIN / DSC")
        ),
        ServiceCatalogItem(
            id = "online_jobs",
            title = "Online Job Forms (Sarkari Bharti)",
            category = ServiceCategory.ONLINE_FORMS,
            summary = "Error-free filling for UP Police, SSC, Railway, Army Agniveer, UPSC, TET & Banking exams.",
            feeLabel = "₹99 + Exam Fee",
            turnaroundTime = "30 Mins",
            requiredDocs = listOf("10th/12th Marksheet", "Passport Photo & Signature", "Aadhaar & Caste Cert")
        ),
        ServiceCatalogItem(
            id = "admission_forms",
            title = "College Admission Forms",
            category = ServiceCategory.ONLINE_FORMS,
            summary = "University entrance, BA/BSc/BCom/PG admissions, CUET, B.Ed, and counseling registration.",
            feeLabel = "₹149 + Portal Fee",
            turnaroundTime = "Same Day",
            requiredDocs = listOf("Previous Marksheets", "TC / Migration", "Photo & Mobile OTP")
        ),
        ServiceCatalogItem(
            id = "scholarship_forms",
            title = "Scholarship Forms (UP & NSP)",
            category = ServiceCategory.ONLINE_FORMS,
            summary = "UP Pre/Post Matric Scholarship, National Scholarship Portal fresh & renewal submission.",
            feeLabel = "₹149",
            turnaroundTime = "Same Day",
            requiredDocs = listOf("Income & Caste Cert", "Aadhaar Seeded Bank Passbook", "Fee Receipt")
        ),
        ServiceCatalogItem(
            id = "pan_online",
            title = "PAN Card & Online Citizen Services",
            category = ServiceCategory.ONLINE_FORMS,
            summary = "New PAN, correction/reprint, PAN-Aadhaar linking, and UP e-District certificates.",
            feeLabel = "Starts ₹199",
            turnaroundTime = "2–7 Days",
            requiredDocs = listOf("Aadhaar Card", "2 Passport Photos")
        )
    )

    val governmentDocuments: List<GovtDocumentService> = listOf(
        // 1. Identity Proofs (5)
        GovtDocumentService(
            id = "doc_aadhaar",
            title = "Aadhaar Card Services",
            subtitle = "Address update assistance, PVC card order, demographic check & document update.",
            category = GovtDocCategory.IDENTITY,
            turnaroundTime = "5–10 Days",
            feeHint = "₹100+",
            docsNeeded = "Existing Aadhaar + Address Proof"
        ),
        GovtDocumentService(
            id = "doc_pan",
            title = "PAN Card Application",
            subtitle = "New NSDL/UTIITSL PAN card, name/DOB correction, and lost PAN reprint.",
            category = GovtDocCategory.IDENTITY,
            turnaroundTime = "3–7 Days",
            feeHint = "₹250",
            docsNeeded = "Aadhaar Card + 2 Photos"
        ),
        GovtDocumentService(
            id = "doc_voter",
            title = "Voter ID Card (EPIC)",
            subtitle = "Form 6 new voter enrollment, constituency transfer, and EPIC digital download.",
            category = GovtDocCategory.IDENTITY,
            turnaroundTime = "15–30 Days",
            feeHint = "₹100",
            docsNeeded = "Aadhaar + Age Proof + Photo"
        ),
        GovtDocumentService(
            id = "doc_passport",
            title = "Passport Application",
            subtitle = "Fresh & Tatkaal Passport Seva form submission and PSK appointment booking.",
            category = GovtDocCategory.IDENTITY,
            turnaroundTime = "Appointment in 2–5 Days",
            feeHint = "₹499 + Govt Fee",
            docsNeeded = "Aadhaar + PAN + 10th Marksheet"
        ),
        GovtDocumentService(
            id = "doc_dl",
            title = "Driving License Desk",
            subtitle = "Sarathi Parivahan Learner License (LL), Permanent DL, and license renewal.",
            category = GovtDocCategory.IDENTITY,
            turnaroundTime = "7–15 Days",
            feeHint = "₹399 + RTO Fee",
            docsNeeded = "Aadhaar + Blood Group + Photo"
        ),
        // 2. Certificates — UP e-District (4)
        GovtDocumentService(
            id = "doc_income",
            title = "Income Certificate (Aay Praman)",
            subtitle = "Official UP e-District Tehsil verified annual family income certificate.",
            category = GovtDocCategory.CERTIFICATES,
            turnaroundTime = "7–10 Days",
            feeHint = "₹120",
            docsNeeded = "Aadhaar + Self-Declaration + Photo"
        ),
        GovtDocumentService(
            id = "doc_caste",
            title = "Caste Certificate (Jati Praman)",
            subtitle = "State & Central OBC / SC / ST caste certificate application via e-District.",
            category = GovtDocCategory.CERTIFICATES,
            turnaroundTime = "7–10 Days",
            feeHint = "₹120",
            docsNeeded = "Aadhaar + Ration Card / Pradhan Proof"
        ),
        GovtDocumentService(
            id = "doc_domicile",
            title = "Residence / Domicile (Niwas Praman)",
            subtitle = "Official Uttar Pradesh permanent residence certificate for jobs & admissions.",
            category = GovtDocCategory.CERTIFICATES,
            turnaroundTime = "7–10 Days",
            feeHint = "₹120",
            docsNeeded = "Aadhaar + Electricity Bill / Voter ID"
        ),
        GovtDocumentService(
            id = "doc_birth_death",
            title = "Birth & Death Certificates",
            subtitle = "CRS / Nagar Panchayat / Gram Panchayat registration & digital certificate copy.",
            category = GovtDocCategory.CERTIFICATES,
            turnaroundTime = "10–15 Days",
            feeHint = "₹150",
            docsNeeded = "Hospital Slip / Affidavit + Parents ID"
        ),
        // 3. Other Essential Documents (2)
        GovtDocumentService(
            id = "doc_ration",
            title = "Ration Card (UP FCS NFSA)",
            subtitle = "New Patra Grihasthi / Antyodaya card, family member addition, and e-KYC.",
            category = GovtDocCategory.ESSENTIALS,
            turnaroundTime = "15–30 Days",
            feeHint = "₹150",
            docsNeeded = "All Members Aadhaar + Bank Passbook + Income Cert"
        ),
        GovtDocumentService(
            id = "doc_ayushman",
            title = "Ayushman Bharat (PM-JAY)",
            subtitle = "Beneficiary eligibility verification, e-KYC, and Golden Health Card download.",
            category = GovtDocCategory.ESSENTIALS,
            turnaroundTime = "Same Day",
            feeHint = "₹100",
            docsNeeded = "Aadhaar Card + Ration Card / PM Letter"
        )
    )

    val contactServiceOptions: List<String> = listOf(
        "GST Registration",
        "GST Return Filing (GSTR-1, 3B, 9)",
        "GST Amendment & Cancellation",
        "ITR Filing (Salaried & Business)",
        "Balance Sheet & Profit & Loss",
        "ROC AOC-4 & MGT-7 Filing",
        "Government Documents (Aadhaar / PAN / Certificates)",
        "Online Job / Admission / Scholarship Forms",
        "Other Tax & Business Consultation"
    )
}
