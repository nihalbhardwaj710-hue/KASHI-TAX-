package com.example.data.remote

import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface SupabaseApiService {

    // 1. Supabase Auth — Sign Up, Sign In & Refresh Token
    @POST("auth/v1/signup")
    suspend fun signUp(
        @Header("apikey") apiKey: String,
        @Body request: SupabaseSignUpRequest
    ): Response<SupabaseAuthResponse>

    @POST("auth/v1/token?grant_type=password")
    suspend fun signInWithPassword(
        @Header("apikey") apiKey: String,
        @Body request: SupabaseSignInRequest
    ): Response<SupabaseAuthResponse>

    @POST("auth/v1/token?grant_type=refresh_token")
    suspend fun refreshSession(
        @Header("apikey") apiKey: String,
        @Body request: SupabaseRefreshTokenRequest
    ): Response<SupabaseAuthResponse>

    // 2. Supabase PostgREST — Enquiries CRUD
    @Headers("Prefer: return=representation")
    @POST("rest/v1/enquiries")
    suspend fun insertEnquiry(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Body payload: SupabaseEnquiryInsertDto
    ): Response<List<SupabaseEnquiryDto>>

    @GET("rest/v1/enquiries")
    suspend fun fetchEnquiries(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc"
    ): Response<List<SupabaseEnquiryDto>>

    @PATCH("rest/v1/enquiries")
    suspend fun updateEnquiryStatus(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Query("id") idFilter: String,
        @Body body: SupabaseStatusUpdateDto
    ): Response<Unit>

    @DELETE("rest/v1/enquiries")
    suspend fun deleteEnquiry(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Query("id") idFilter: String
    ): Response<Unit>

    // 3. Supabase PostgREST — Per-Customer Private Document Records (RLS enforced)
    @Headers("Prefer: return=representation")
    @POST("rest/v1/customer_documents")
    suspend fun insertCustomerDocument(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Body payload: CustomerDocumentInsertDto
    ): Response<List<CustomerDocumentDto>>

    @GET("rest/v1/customer_documents")
    suspend fun fetchCustomerDocuments(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc"
    ): Response<List<CustomerDocumentDto>>

    @DELETE("rest/v1/customer_documents")
    suspend fun deleteCustomerDocumentRecord(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Query("id") idFilter: String
    ): Response<Unit>

    // 4. Supabase Private Storage (`documents` bucket — Authenticated JWT Only)
    @Headers("x-upsert: true")
    @POST("storage/v1/object/{bucket}/{objectPath}")
    suspend fun uploadStorageObject(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Path("bucket") bucket: String,
        @Path(value = "objectPath", encoded = true) objectPath: String,
        @Body fileBody: RequestBody
    ): Response<Unit>

    @POST("storage/v1/object/sign/{bucket}/{objectPath}")
    suspend fun createSignedDownloadUrl(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Path("bucket") bucket: String,
        @Path(value = "objectPath", encoded = true) objectPath: String,
        @Body body: SupabaseSignedUrlRequest = SupabaseSignedUrlRequest(expiresIn = 300)
    ): Response<SupabaseSignedUrlResponse>

    @DELETE("storage/v1/object/{bucket}/{objectPath}")
    suspend fun deleteStorageObject(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Path("bucket") bucket: String,
        @Path(value = "objectPath", encoded = true) objectPath: String
    ): Response<Unit>
}
