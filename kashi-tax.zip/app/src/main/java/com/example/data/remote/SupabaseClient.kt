package com.example.data.remote

import com.squareup.moshi.Moshi
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object SupabaseClient {

    @Volatile
    private var cachedBaseUrl: String? = null

    @Volatile
    private var cachedService: SupabaseApiService? = null

    fun getService(): SupabaseApiService? {
        if (!SupabaseConfig.isConfigured) return null
        val url = "${SupabaseConfig.baseUrl}/"
        if (cachedService != null && cachedBaseUrl == url) {
            return cachedService
        }
        return synchronized(this) {
            if (cachedService != null && cachedBaseUrl == url) {
                return@synchronized cachedService
            }
            val logger = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }
            val client = OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(25, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .addInterceptor(logger)
                .build()

            val moshi = Moshi.Builder().build()

            val service = Retrofit.Builder()
                .baseUrl(url)
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(SupabaseApiService::class.java)

            cachedBaseUrl = url
            cachedService = service
            service
        }
    }
}
