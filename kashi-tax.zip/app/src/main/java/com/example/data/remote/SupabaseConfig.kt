package com.example.data.remote

import com.example.BuildConfig

object SupabaseConfig {
    // Existing private Supabase Storage bucket name (public = false)
    const val STORAGE_BUCKET = "documents"

    val baseUrl: String
        get() = BuildConfig.SUPABASE_URL.trim().trimEnd('/')

    // Publishable / Anon Key only — NEVER embed service_role or secret keys in the Android app
    val anonKey: String
        get() = BuildConfig.SUPABASE_ANON_KEY.trim()

    val isConfigured: Boolean
        get() = baseUrl.startsWith("https://") &&
            !baseUrl.contains("YOUR_PROJECT_REF", ignoreCase = true) &&
            anonKey.isNotBlank() &&
            !anonKey.contains("YOUR_SUPABASE_ANON_KEY", ignoreCase = true)
}
