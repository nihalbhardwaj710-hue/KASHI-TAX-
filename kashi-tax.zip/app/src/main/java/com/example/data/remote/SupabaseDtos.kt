package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class SupabaseEnquiryInsertDto(
    @Json(name = "reference_code") val referenceCode: String,
    @Json(name = "customer_name") val customerName: String,
    @Json(name = "mobile_number") val mobileNumber: String,
    @Json(name = "service_category") val serviceCategory: String,
    @Json(name = "service_name") val serviceName: String,
    @Json(name = "message") val message: String,
    @Json(name = "attached_documents") val attachedDocuments: String,
    @Json(name = "payment_mode") val paymentMode: String,
    @Json(name = "payment_proof") val paymentProof: String,
    @Json(name = "status") val status: String,
    @Json(name = "priority") val priority: String
)

@JsonClass(generateAdapter = true)
data class SupabaseEnquiryDto(
    @Json(name = "id") val id: String,
    @Json(name = "reference_code") val referenceCode: String,
    @Json(name = "customer_name") val customerName: String,
    @Json(name = "mobile_number") val mobileNumber: String,
    @Json(name = "service_category") val serviceCategory: String,
    @Json(name = "service_name") val serviceName: String,
    @Json(name = "message") val message: String = "",
    @Json(name = "attached_documents") val attachedDocuments: String = "",
    @Json(name = "payment_mode") val paymentMode: String = "NONE",
    @Json(name = "payment_proof") val paymentProof: String = "",
    @Json(name = "status") val status: String = "PENDING",
    @Json(name = "priority") val priority: String = "STANDARD",
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class SupabaseStatusUpdateDto(
    @Json(name = "status") val status: String
)

@JsonClass(generateAdapter = true)
data class SupabaseSignInRequest(
    @Json(name = "email") val email: String,
    @Json(name = "password") val password: String
)

@JsonClass(generateAdapter = true)
data class SupabaseSignUpRequest(
    @Json(name = "email") val email: String,
    @Json(name = "password") val password: String
)

@JsonClass(generateAdapter = true)
data class SupabaseRefreshTokenRequest(
    @Json(name = "refresh_token") val refreshToken: String
)

@JsonClass(generateAdapter = true)
data class SupabaseAuthUser(
    @Json(name = "id") val id: String? = null,
    @Json(name = "email") val email: String? = null
)

@JsonClass(generateAdapter = true)
data class SupabaseAuthResponse(
    @Json(name = "access_token") val accessToken: String? = null,
    @Json(name = "refresh_token") val refreshToken: String? = null,
    @Json(name = "user") val user: SupabaseAuthUser? = null
)

@JsonClass(generateAdapter = true)
data class SupabaseSignedUrlRequest(
    @Json(name = "expiresIn") val expiresIn: Int = 300
)

@JsonClass(generateAdapter = true)
data class SupabaseSignedUrlResponse(
    @Json(name = "signedURL") val signedUrl: String
)

@JsonClass(generateAdapter = true)
data class CustomerDocumentInsertDto(
    @Json(name = "user_id") val userId: String,
    @Json(name = "category") val category: String,
    @Json(name = "file_name") val fileName: String,
    @Json(name = "storage_path") val storagePath: String,
    @Json(name = "mime_type") val mimeType: String,
    @Json(name = "file_size_bytes") val fileSizeBytes: Long
)

@JsonClass(generateAdapter = true)
data class CustomerDocumentDto(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String,
    @Json(name = "category") val category: String,
    @Json(name = "file_name") val fileName: String,
    @Json(name = "storage_path") val storagePath: String,
    @Json(name = "mime_type") val mimeType: String = "application/octet-stream",
    @Json(name = "file_size_bytes") val fileSizeBytes: Long = 0L,
    @Json(name = "created_at") val createdAt: String? = null
)
