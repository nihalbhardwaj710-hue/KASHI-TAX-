package com.example.data.repository

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.widget.Toast
import com.example.data.local.CustomerAuthPreferences
import com.example.data.local.CustomerAuthSession
import com.example.data.remote.CustomerDocumentDto
import com.example.data.remote.CustomerDocumentInsertDto
import com.example.data.remote.SupabaseClient
import com.example.data.remote.SupabaseConfig
import com.example.data.remote.SupabaseRefreshTokenRequest
import com.example.data.remote.SupabaseSignInRequest
import com.example.data.remote.SupabaseSignUpRequest
import com.example.data.remote.SupabaseSignedUrlRequest
import com.example.util.DocumentStorageHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

enum class VaultDocumentCategory(val apiValue: String, val displayLabel: String) {
    GST("GST", "GST"),
    ITR("ITR", "ITR"),
    PAN("PAN", "PAN"),
    AADHAAR("Aadhaar", "Aadhaar"),
    OTHER("Other", "Other")
}

sealed class CustomerAuthResult {
    data class Authenticated(val message: String) : CustomerAuthResult()
    data class VerificationRequired(val message: String) : CustomerAuthResult()
    data class Error(val message: String) : CustomerAuthResult()
}

class CustomerDocumentRepository(
    private val context: Context,
    private val authPreferences: CustomerAuthPreferences
) {
    val sessionFlow: Flow<CustomerAuthSession> = authPreferences.sessionFlow

    val isSupabaseConfigured: Boolean
        get() = SupabaseConfig.isConfigured

    suspend fun signUp(email: String, password: String): CustomerAuthResult = withContext(Dispatchers.IO) {
        val api = SupabaseClient.getService()
            ?: return@withContext CustomerAuthResult.Error(
                "Supabase configure nahi hai. AI Studio Secrets me SUPABASE_URL aur SUPABASE_ANON_KEY add karein."
            )

        runCatching {
            val response = api.signUp(
                apiKey = SupabaseConfig.anonKey,
                request = SupabaseSignUpRequest(email = email.trim(), password = password)
            )
            if (!response.isSuccessful) {
                val errText = response.errorBody()?.string().orEmpty()
                return@withContext CustomerAuthResult.Error(
                    parseSupabaseError(errText, "Account create nahi ho saka (HTTP ${response.code()}).")
                )
            }
            val body = response.body()
            val token = body?.accessToken.orEmpty()
            val userId = body?.user?.id.orEmpty()
            val userEmail = body?.user?.email ?: email.trim()

            if (token.isNotBlank() && userId.isNotBlank()) {
                authPreferences.saveSession(
                    userId = userId,
                    email = userEmail,
                    accessToken = token,
                    refreshToken = body?.refreshToken.orEmpty()
                )
                CustomerAuthResult.Authenticated("Account ban gaya! Ab aap apne private documents upload kar sakte hain.")
            } else {
                CustomerAuthResult.VerificationRequired(
                    "Verification link aapke email ($userEmail) par bheja gaya hai. Email confirm karke Sign In karein."
                )
            }
        }.getOrElse { ex ->
            CustomerAuthResult.Error("Network error: ${ex.localizedMessage ?: "Internet check karein"}")
        }
    }

    suspend fun signIn(email: String, password: String): CustomerAuthResult = withContext(Dispatchers.IO) {
        val api = SupabaseClient.getService()
            ?: return@withContext CustomerAuthResult.Error(
                "Supabase configure nahi hai. AI Studio Secrets me SUPABASE_URL aur SUPABASE_ANON_KEY add karein."
            )

        runCatching {
            val response = api.signInWithPassword(
                apiKey = SupabaseConfig.anonKey,
                request = SupabaseSignInRequest(email = email.trim(), password = password)
            )
            if (!response.isSuccessful) {
                val errText = response.errorBody()?.string().orEmpty()
                return@withContext CustomerAuthResult.Error(
                    parseSupabaseError(errText, "Invalid email ya password (HTTP ${response.code()}).")
                )
            }
            val body = response.body()
            val token = body?.accessToken.orEmpty()
            val userId = body?.user?.id.orEmpty()
            if (token.isBlank() || userId.isBlank()) {
                return@withContext CustomerAuthResult.Error("Supabase se valid session nahi mila.")
            }
            authPreferences.saveSession(
                userId = userId,
                email = body?.user?.email ?: email.trim(),
                accessToken = token,
                refreshToken = body?.refreshToken.orEmpty()
            )
            CustomerAuthResult.Authenticated("Private Document Vault unlock ho gaya.")
        }.getOrElse { ex ->
            CustomerAuthResult.Error("Network error: ${ex.localizedMessage ?: "Internet check karein"}")
        }
    }

    suspend fun signOut() {
        authPreferences.clearSession()
    }

    suspend fun fetchMyDocuments(): Result<List<CustomerDocumentDto>> = withContext(Dispatchers.IO) {
        val api = SupabaseClient.getService()
            ?: return@withContext Result.failure(IllegalStateException("Supabase configured nahi hai."))

        executeWithRefresh { session ->
            val response = api.fetchCustomerDocuments(
                apiKey = SupabaseConfig.anonKey,
                bearerToken = "Bearer ${session.accessToken}"
            )
            if (response.isSuccessful) {
                Result.success(response.body().orEmpty())
            } else {
                Result.failure(HttpStatusException(response.code(), "Documents load nahi ho sake (HTTP ${response.code()})."))
            }
        }
    }

    suspend fun uploadUriDocument(
        uri: Uri,
        category: VaultDocumentCategory
    ): Result<CustomerDocumentDto> = withContext(Dispatchers.IO) {
        val persisted = DocumentStorageHelper.persistUri(context, uri)
            ?: return@withContext Result.failure(IllegalStateException("Selected file read nahi ho saki."))
        val localFile = DocumentStorageHelper.getUploadedFile(context, persisted.storedFileName)
            ?: return@withContext Result.failure(IllegalStateException("Local file cache nahi mili."))
        uploadLocalFile(
            localFile = localFile,
            originalDisplayName = persisted.displayName,
            category = category
        )
    }

    suspend fun uploadCameraFile(
        tempFile: File,
        category: VaultDocumentCategory
    ): Result<CustomerDocumentDto> = withContext(Dispatchers.IO) {
        val persisted = DocumentStorageHelper.persistCameraFile(context, tempFile, category.apiValue)
            ?: return@withContext Result.failure(IllegalStateException("Camera photo save nahi ho saki."))
        val localFile = DocumentStorageHelper.getUploadedFile(context, persisted.storedFileName)
            ?: return@withContext Result.failure(IllegalStateException("Camera photo file nahi mili."))
        uploadLocalFile(
            localFile = localFile,
            originalDisplayName = persisted.displayName,
            category = category
        )
    }

    private suspend fun uploadLocalFile(
        localFile: File,
        originalDisplayName: String,
        category: VaultDocumentCategory
    ): Result<CustomerDocumentDto> {
        val api = SupabaseClient.getService()
            ?: return Result.failure(IllegalStateException("Supabase configured nahi hai."))

        val cleanName = sanitizeFileName(originalDisplayName)
        val mimeType = DocumentStorageHelper.guessMimeType(localFile.name)
        val fileSize = localFile.length()

        return executeWithRefresh { session ->
            // Strict per-user path: {user_id}/{category}/{timestamp}_{uuid}_{cleanName}
            val uniquePrefix = "${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}"
            val storagePath = "${session.userId}/${category.apiValue}/${uniquePrefix}_$cleanName"

            val requestBody = localFile.asRequestBody(mimeType.toMediaTypeOrNull())
            val uploadResp = api.uploadStorageObject(
                apiKey = SupabaseConfig.anonKey,
                bearerToken = "Bearer ${session.accessToken}",
                bucket = SupabaseConfig.STORAGE_BUCKET,
                objectPath = storagePath,
                fileBody = requestBody
            )
            if (!uploadResp.isSuccessful) {
                return@executeWithRefresh Result.failure(
                    HttpStatusException(
                        uploadResp.code(),
                        "Private storage upload fail hua (HTTP ${uploadResp.code()}). Bucket 'documents' aur RLS policy check karein."
                    )
                )
            }

            val metaResp = api.insertCustomerDocument(
                apiKey = SupabaseConfig.anonKey,
                bearerToken = "Bearer ${session.accessToken}",
                payload = CustomerDocumentInsertDto(
                    userId = session.userId,
                    category = category.apiValue,
                    fileName = originalDisplayName,
                    storagePath = storagePath,
                    mimeType = mimeType,
                    fileSizeBytes = fileSize
                )
            )
            if (!metaResp.isSuccessful) {
                return@executeWithRefresh Result.failure(
                    HttpStatusException(
                        metaResp.code(),
                        "Document metadata save nahi ho saka (HTTP ${metaResp.code()})."
                    )
                )
            }
            val inserted = metaResp.body()?.firstOrNull()
                ?: return@executeWithRefresh Result.failure(IllegalStateException("Uploaded document record return nahi hua."))
            Result.success(inserted)
        }
    }

    suspend fun createSignedUrl(storagePath: String): Result<String> = withContext(Dispatchers.IO) {
        val api = SupabaseClient.getService()
            ?: return@withContext Result.failure(IllegalStateException("Supabase configured nahi hai."))

        executeWithRefresh { session ->
            val response = api.createSignedDownloadUrl(
                apiKey = SupabaseConfig.anonKey,
                bearerToken = "Bearer ${session.accessToken}",
                bucket = SupabaseConfig.STORAGE_BUCKET,
                objectPath = storagePath.trimStart('/'),
                body = SupabaseSignedUrlRequest(expiresIn = 300)
            )
            if (!response.isSuccessful) {
                return@executeWithRefresh Result.failure(
                    HttpStatusException(response.code(), "Private link generate nahi ho saka (HTTP ${response.code()}).")
                )
            }
            val rawSigned = response.body()?.signedUrl.orEmpty()
            val fullUrl = if (rawSigned.startsWith("http")) {
                rawSigned
            } else {
                "${SupabaseConfig.baseUrl}/storage/v1$rawSigned"
            }
            Result.success(fullUrl)
        }
    }

    suspend fun downloadDocument(doc: CustomerDocumentDto): Result<String> = withContext(Dispatchers.IO) {
        val signedResult = createSignedUrl(doc.storagePath)
        val signedUrl = signedResult.getOrElse { return@withContext Result.failure(it) }

        val safeName = sanitizeFileName(doc.fileName)
        return@withContext runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Zero-permission Scoped Storage download into system Downloads with notification
                val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                val request = DownloadManager.Request(Uri.parse(signedUrl))
                    .setTitle(doc.fileName)
                    .setDescription("Kashi Tax Private Document (${doc.category})")
                    .setMimeType(doc.mimeType)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "KashiTax_$safeName")
                downloadManager.enqueue(request)
                "Downloads folder me download start ho gaya: KashiTax_$safeName"
            } else {
                // Zero-permission app-scoped downloads fallback on Android 7–9
                val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
                val target = File(downloadsDir, "KashiTax_$safeName")
                val httpClient = OkHttpClient()
                val req = Request.Builder().url(signedUrl).build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) error("Download failed (HTTP ${resp.code})")
                    resp.body?.byteStream()?.use { input ->
                        FileOutputStream(target).use { output -> input.copyTo(output) }
                    }
                }
                "Saved: ${target.name}"
            }
        }
    }

    suspend fun deleteDocument(doc: CustomerDocumentDto): Result<Unit> = withContext(Dispatchers.IO) {
        val api = SupabaseClient.getService()
            ?: return@withContext Result.failure(IllegalStateException("Supabase configured nahi hai."))

        executeWithRefresh { session ->
            val storageResp = api.deleteStorageObject(
                apiKey = SupabaseConfig.anonKey,
                bearerToken = "Bearer ${session.accessToken}",
                bucket = SupabaseConfig.STORAGE_BUCKET,
                objectPath = doc.storagePath.trimStart('/')
            )
            if (!storageResp.isSuccessful && storageResp.code() != 404) {
                return@executeWithRefresh Result.failure(
                    HttpStatusException(storageResp.code(), "Storage se file delete nahi hui (HTTP ${storageResp.code()}).")
                )
            }

            val dbResp = api.deleteCustomerDocumentRecord(
                apiKey = SupabaseConfig.anonKey,
                bearerToken = "Bearer ${session.accessToken}",
                idFilter = "eq.${doc.id}"
            )
            if (!dbResp.isSuccessful) {
                return@executeWithRefresh Result.failure(
                    HttpStatusException(dbResp.code(), "Document record delete nahi hua (HTTP ${dbResp.code()}).")
                )
            }
            Result.success(Unit)
        }
    }

    private suspend fun <T> executeWithRefresh(
        block: suspend (CustomerAuthSession) -> Result<T>
    ): Result<T> {
        val session = authPreferences.getCurrentSession()
        if (!session.isAuthenticated) {
            return Result.failure(IllegalStateException("Kripya apne account me Sign In karein."))
        }
        val firstTry = block(session)
        val exception = firstTry.exceptionOrNull()
        if (exception is HttpStatusException && exception.code == 401 && session.refreshToken.isNotBlank()) {
            val refreshed = refreshAccessToken(session)
            if (refreshed != null) {
                return block(refreshed)
            } else {
                authPreferences.clearSession()
                return Result.failure(IllegalStateException("Session expire ho gaya. Kripya dobara Sign In karein."))
            }
        }
        return firstTry
    }

    private suspend fun refreshAccessToken(current: CustomerAuthSession): CustomerAuthSession? {
        val api = SupabaseClient.getService() ?: return null
        return runCatching {
            val resp = api.refreshSession(
                apiKey = SupabaseConfig.anonKey,
                request = SupabaseRefreshTokenRequest(refreshToken = current.refreshToken)
            )
            if (resp.isSuccessful) {
                val body = resp.body()
                val newAccess = body?.accessToken.orEmpty()
                if (newAccess.isNotBlank()) {
                    val updated = CustomerAuthSession(
                        userId = body?.user?.id ?: current.userId,
                        email = body?.user?.email ?: current.email,
                        accessToken = newAccess,
                        refreshToken = body?.refreshToken ?: current.refreshToken
                    )
                    authPreferences.saveSession(
                        userId = updated.userId,
                        email = updated.email,
                        accessToken = updated.accessToken,
                        refreshToken = updated.refreshToken
                    )
                    updated
                } else null
            } else null
        }.getOrNull()
    }

    private fun sanitizeFileName(raw: String): String {
        val cleaned = raw.trim().replace(Regex("[^a-zA-Z0-9._-]"), "_")
        return cleaned.takeIf { it.isNotBlank() }?.take(80) ?: "document.pdf"
    }

    private fun parseSupabaseError(rawJson: String, fallback: String): String {
        val msgRegex = Regex("\"(?:error_description|msg|message)\"\\s*:\\s*\"([^\"]+)\"")
        return msgRegex.find(rawJson)?.groupValues?.getOrNull(1) ?: fallback
    }

    private class HttpStatusException(val code: Int, message: String) : Exception(message)
}
