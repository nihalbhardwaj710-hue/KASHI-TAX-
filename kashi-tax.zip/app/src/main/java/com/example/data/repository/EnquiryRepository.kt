package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.AdminAuthSnapshot
import com.example.data.local.AdminPreferences
import com.example.data.local.CustomerAuthPreferences
import com.example.data.local.EnquiryDao
import com.example.data.local.EnquiryEntity
import com.example.data.local.EnquiryPriority
import com.example.data.local.EnquiryStatus
import com.example.data.local.PaymentMode
import com.example.data.remote.SupabaseClient
import com.example.data.remote.SupabaseConfig
import com.example.data.remote.SupabaseEnquiryInsertDto
import com.example.data.remote.SupabaseSignInRequest
import com.example.data.remote.SupabaseStatusUpdateDto
import com.example.util.DocumentStorageHelper
import com.example.util.PersistedAttachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.random.Random

sealed class AdminLoginResult {
    data object Success : AdminLoginResult()
    data class Error(val message: String) : AdminLoginResult()
}

class EnquiryRepository(
    private val context: Context,
    private val enquiryDao: EnquiryDao,
    private val adminPreferences: AdminPreferences,
    private val customerAuthPreferences: CustomerAuthPreferences
) {
    val allEnquiries: Flow<List<EnquiryEntity>> = enquiryDao.observeAllEnquiries()
    val unreadCount: Flow<Int> = enquiryDao.observeUnreadCount()
    val adminAuthState: Flow<AdminAuthSnapshot> = adminPreferences.authStateFlow

    val isSupabaseConfigured: Boolean
        get() = SupabaseConfig.isConfigured

    suspend fun submitEnquiry(
        customerName: String,
        mobileNumber: String,
        serviceCategory: String,
        serviceName: String,
        message: String,
        encodedDocuments: String = "",
        paymentMode: String = PaymentMode.NONE,
        encodedPaymentProof: String = "",
        prefix: String = "KTS"
    ): EnquiryEntity {
        val codeNumber = Random.nextInt(10000, 99999)
        val referenceCode = "$prefix-$codeNumber"
        val priority = if (paymentMode == PaymentMode.PAY_ADVANCE) {
            EnquiryPriority.URGENT
        } else {
            EnquiryPriority.STANDARD
        }

        val entity = EnquiryEntity(
            referenceCode = referenceCode,
            customerName = customerName.trim(),
            mobileNumber = mobileNumber.filter { it.isDigit() }.takeLast(10),
            serviceCategory = serviceCategory,
            serviceName = serviceName.trim(),
            message = message.trim(),
            attachedDocuments = encodedDocuments,
            paymentMode = paymentMode,
            paymentProofName = encodedPaymentProof,
            status = EnquiryStatus.PENDING,
            priority = priority,
            isReadByAdmin = false,
            isSyncedToCloud = false,
            createdAtMillis = System.currentTimeMillis()
        )
        val insertedId = enquiryDao.insertEnquiry(entity)
        val savedLocal = entity.copy(id = insertedId)

        if (SupabaseConfig.isConfigured) {
            pushEnquiryToSupabase(savedLocal)
        }
        return savedLocal
    }

    suspend fun syncWithSupabase(): Result<Int> = withContext(Dispatchers.IO) {
        val api = SupabaseClient.getService()
            ?: return@withContext Result.failure(IllegalStateException("Supabase is not configured yet."))

        val accessToken = adminPreferences.getSupabaseAccessToken()
        if (accessToken.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Sign in with your Supabase Admin account to sync."))
        }

        return@withContext runCatching {
            val unsynced = enquiryDao.getUnsyncedEnquiries()
            unsynced.forEach { localItem ->
                pushEnquiryToSupabase(localItem)
            }

            val response = api.fetchEnquiries(
                apiKey = SupabaseConfig.anonKey,
                bearerToken = "Bearer $accessToken"
            )
            if (!response.isSuccessful) {
                throw IllegalStateException("Supabase sync failed (HTTP ${response.code()})")
            }

            val remoteItems = response.body().orEmpty()
            remoteItems.forEach { dto ->
                val existing = enquiryDao.findByReferenceCode(dto.referenceCode)
                val merged = EnquiryEntity(
                    id = existing?.id ?: 0L,
                    remoteId = dto.id,
                    referenceCode = dto.referenceCode,
                    customerName = dto.customerName,
                    mobileNumber = dto.mobileNumber,
                    serviceCategory = dto.serviceCategory,
                    serviceName = dto.serviceName,
                    message = dto.message,
                    attachedDocuments = dto.attachedDocuments.ifBlank { existing?.attachedDocuments.orEmpty() },
                    paymentMode = dto.paymentMode,
                    paymentProofName = dto.paymentProof.ifBlank { existing?.paymentProofName.orEmpty() },
                    status = dto.status,
                    priority = dto.priority,
                    isReadByAdmin = existing?.isReadByAdmin ?: true,
                    isSyncedToCloud = true,
                    createdAtMillis = parseIsoTimestamp(dto.createdAt)
                        ?: existing?.createdAtMillis
                        ?: System.currentTimeMillis()
                )
                enquiryDao.insertEnquiry(merged)
            }
            remoteItems.size
        }
    }

    suspend fun toggleEnquiryStatus(enquiry: EnquiryEntity) {
        val nextStatus = if (enquiry.status == EnquiryStatus.COMPLETED) {
            EnquiryStatus.PENDING
        } else {
            EnquiryStatus.COMPLETED
        }
        enquiryDao.updateEnquiryStatus(enquiry.id, nextStatus)

        val remoteId = enquiry.remoteId ?: return
        val api = SupabaseClient.getService() ?: return
        val token = adminPreferences.getSupabaseAccessToken()
        if (token.isBlank()) return

        withContext(Dispatchers.IO) {
            runCatching {
                api.updateEnquiryStatus(
                    apiKey = SupabaseConfig.anonKey,
                    bearerToken = "Bearer $token",
                    idFilter = "eq.$remoteId",
                    body = SupabaseStatusUpdateDto(status = nextStatus)
                )
            }.onFailure {
                Log.w(TAG, "Failed to update status in Supabase", it)
            }
        }
    }

    suspend fun markAllRead() {
        enquiryDao.markAllReadByAdmin()
    }

    suspend fun deleteEnquiry(id: Long) {
        val existing = enquiryDao.findById(id)
        enquiryDao.deleteEnquiryById(id)

        val remoteId = existing?.remoteId ?: return
        val api = SupabaseClient.getService() ?: return
        val token = adminPreferences.getSupabaseAccessToken()
        if (token.isBlank()) return

        withContext(Dispatchers.IO) {
            runCatching {
                api.deleteEnquiry(
                    apiKey = SupabaseConfig.anonKey,
                    bearerToken = "Bearer $token",
                    idFilter = "eq.$remoteId"
                )
            }.onFailure {
                Log.w(TAG, "Failed to delete enquiry in Supabase", it)
            }
        }
    }

    suspend fun getSignedDocumentUrl(attachment: PersistedAttachment): String? = withContext(Dispatchers.IO) {
        val api = SupabaseClient.getService() ?: return@withContext null
        val token = adminPreferences.getSupabaseAccessToken()
            .ifBlank { customerAuthPreferences.getCurrentSession().accessToken }
        if (token.isBlank() || attachment.storedFileName.isBlank()) return@withContext null

        val objectPath = attachment.storedFileName.trimStart('/')
        return@withContext runCatching {
            val response = api.createSignedDownloadUrl(
                apiKey = SupabaseConfig.anonKey,
                bearerToken = "Bearer $token",
                bucket = SupabaseConfig.STORAGE_BUCKET,
                objectPath = objectPath
            )
            if (response.isSuccessful) {
                val signedPath = response.body()?.signedUrl.orEmpty()
                if (signedPath.startsWith("http")) signedPath
                else "${SupabaseConfig.baseUrl}/storage/v1$signedPath"
            } else {
                null
            }
        }.getOrNull()
    }

    suspend fun setupLocalAdminAccount(email: String, password: String) {
        adminPreferences.setupAdminAccount(email, password)
    }

    suspend fun loginAdmin(email: String, password: String): AdminLoginResult {
        if (SupabaseConfig.isConfigured) {
            val api = SupabaseClient.getService()
                ?: return AdminLoginResult.Error("Supabase client unavailable.")
            return withContext(Dispatchers.IO) {
                runCatching {
                    val response = api.signInWithPassword(
                        apiKey = SupabaseConfig.anonKey,
                        request = SupabaseSignInRequest(email = email.trim(), password = password)
                    )
                    if (response.isSuccessful) {
                        val body = response.body()
                        val accessToken = body?.accessToken.orEmpty()
                        if (accessToken.isNotBlank()) {
                            adminPreferences.saveSupabaseSession(
                                email = body?.user?.email ?: email.trim(),
                                accessToken = accessToken
                            )
                            AdminLoginResult.Success
                        } else {
                            AdminLoginResult.Error("Empty session returned from Supabase.")
                        }
                    } else {
                        AdminLoginResult.Error("Invalid Supabase Admin credentials (HTTP ${response.code()}).")
                    }
                }.getOrElse { ex ->
                    AdminLoginResult.Error("Unable to reach Supabase: ${ex.localizedMessage ?: "Check internet"}")
                }
            }
        } else {
            val matched = adminPreferences.verifyAndLoginLocal(email, password)
            return if (matched) {
                AdminLoginResult.Success
            } else {
                AdminLoginResult.Error("Invalid admin email or password. Please try again.")
            }
        }
    }

    suspend fun logoutAdmin() {
        adminPreferences.logout()
    }

    private suspend fun pushEnquiryToSupabase(entity: EnquiryEntity) = withContext(Dispatchers.IO) {
        val api = SupabaseClient.getService() ?: return@withContext
        val customerSession = customerAuthPreferences.getCurrentSession()
        val enquiryBearer = if (customerSession.isAuthenticated) {
            "Bearer ${customerSession.accessToken}"
        } else {
            "Bearer ${SupabaseConfig.anonKey}"
        }

        // Private `documents` bucket requires an authenticated user JWT; upload only when customer is authenticated
        val localDocs = DocumentStorageHelper.decodeAttachments(entity.attachedDocuments)
        val uploadedDocs = if (customerSession.isAuthenticated) {
            localDocs.map { doc ->
                uploadAttachmentToPrivateBucket(
                    api = api,
                    accessToken = customerSession.accessToken,
                    userId = customerSession.userId,
                    referenceCode = entity.referenceCode,
                    attachment = doc
                )
            }
        } else {
            localDocs
        }

        val localProof = DocumentStorageHelper.decodeSingle(entity.paymentProofName)
        val uploadedProof = if (customerSession.isAuthenticated && localProof != null) {
            uploadAttachmentToPrivateBucket(
                api = api,
                accessToken = customerSession.accessToken,
                userId = customerSession.userId,
                referenceCode = entity.referenceCode,
                attachment = localProof
            )
        } else {
            localProof
        }

        val dto = SupabaseEnquiryInsertDto(
            referenceCode = entity.referenceCode,
            customerName = entity.customerName,
            mobileNumber = entity.mobileNumber,
            serviceCategory = entity.serviceCategory,
            serviceName = entity.serviceName,
            message = entity.message,
            attachedDocuments = DocumentStorageHelper.encodeAttachments(uploadedDocs),
            paymentMode = entity.paymentMode,
            paymentProof = DocumentStorageHelper.encodeSingle(uploadedProof),
            status = entity.status,
            priority = entity.priority
        )

        runCatching {
            val response = api.insertEnquiry(
                apiKey = SupabaseConfig.anonKey,
                bearerToken = enquiryBearer,
                payload = dto
            )
            if (response.isSuccessful) {
                val createdRemoteId = response.body()?.firstOrNull()?.id.orEmpty()
                if (createdRemoteId.isNotBlank()) {
                    enquiryDao.markSynced(entity.id, createdRemoteId)
                }
            } else {
                Log.w(TAG, "Supabase insert failed: HTTP ${response.code()}")
            }
        }.onFailure {
            Log.w(TAG, "Offline or Supabase insert error; kept in local Room queue", it)
        }
    }

    private suspend fun uploadAttachmentToPrivateBucket(
        api: com.example.data.remote.SupabaseApiService,
        accessToken: String,
        userId: String,
        referenceCode: String,
        attachment: PersistedAttachment
    ): PersistedAttachment {
        val file = DocumentStorageHelper.getUploadedFile(context, attachment.storedFileName)
            ?: return attachment
        // Strictly inside authenticated customer's own private folder: {userId}/Other/{refCode}_{file}
        val cloudPath = "$userId/Other/${referenceCode}_${attachment.storedFileName}"
        val mime = DocumentStorageHelper.guessMimeType(file.name)
        val body = file.asRequestBody(mime.toMediaTypeOrNull())
        return runCatching {
            val response = api.uploadStorageObject(
                apiKey = SupabaseConfig.anonKey,
                bearerToken = "Bearer $accessToken",
                bucket = SupabaseConfig.STORAGE_BUCKET,
                objectPath = cloudPath,
                fileBody = body
            )
            if (response.isSuccessful) {
                attachment.copy(storedFileName = cloudPath)
            } else {
                attachment
            }
        }.getOrDefault(attachment)
    }

    private fun parseIsoTimestamp(iso: String?): Long? {
        if (iso.isNullOrBlank()) return null
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss'Z'"
        )
        for (pattern in patterns) {
            val parsed = runCatching {
                SimpleDateFormat(pattern, Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }.parse(iso)?.time
            }.getOrNull()
            if (parsed != null) return parsed
        }
        return null
    }

    companion object {
        private const val TAG = "EnquiryRepository"
    }
}
