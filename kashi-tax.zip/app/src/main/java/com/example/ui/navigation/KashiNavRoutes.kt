package com.example.ui.navigation

object KashiNavRoutes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val SERVICES = "services"
    const val CONTACT = "contact"
    const val ADMIN = "admin"
    const val GST_SERVICES_HUB = "gst_services_hub"
    const val GST_REGISTRATION = "gst_registration"
    const val ITR_SERVICES = "itr_services"
    const val GOVERNMENT_DOCUMENTS = "government_documents"
    const val ONLINE_FORMS = "online_forms"
    const val MY_DOCUMENTS = "my_documents"

    fun contactWithService(service: String): String {
        val encoded = android.net.Uri.encode(service)
        return "$CONTACT?service=$encoded"
    }

    const val CONTACT_PATTERN = "$CONTACT?service={service}"
}
