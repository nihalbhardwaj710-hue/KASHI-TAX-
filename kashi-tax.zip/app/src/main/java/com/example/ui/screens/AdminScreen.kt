package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.AdminAuthSnapshot
import com.example.data.local.EnquiryEntity
import com.example.data.local.EnquiryPriority
import com.example.data.local.EnquiryStatus
import com.example.data.local.PaymentMode
import com.example.data.model.BusinessContact
import com.example.ui.components.StatusPill
import com.example.ui.theme.StatusAmberBg
import com.example.ui.theme.StatusAmberText
import com.example.ui.theme.StatusGreenBg
import com.example.ui.theme.StatusGreenText
import com.example.ui.theme.StatusUrgentBg
import com.example.ui.theme.StatusUrgentText
import com.example.util.DocumentStorageHelper
import com.example.util.IntentUtils
import com.example.util.NotificationHelper

private enum class AdminFilter(val label: String) {
    ALL("All"),
    PENDING("Pending"),
    URGENT("Urgent"),
    COMPLETED("Completed")
}

@Composable
fun AdminScreen(
    authState: AdminAuthSnapshot,
    authError: String?,
    enquiries: List<EnquiryEntity>,
    isSupabaseConfigured: Boolean,
    isSyncingCloud: Boolean,
    syncFeedback: String?,
    onBack: () -> Unit,
    onSetupAdmin: (email: String, password: String, confirm: String) -> Unit,
    onLoginAdmin: (email: String, password: String) -> Unit,
    onLogoutAdmin: () -> Unit,
    onClearError: () -> Unit,
    onSyncCloud: () -> Unit,
    onOpenAttachment: (com.example.util.PersistedAttachment) -> Unit,
    onToggleStatus: (EnquiryEntity) -> Unit,
    onDeleteEnquiry: (Long) -> Unit,
    onMarkAllRead: () -> Unit
) {
    if (!authState.isLoggedIn) {
        AdminAuthGateScreen(
            isConfigured = isSupabaseConfigured || authState.isConfigured,
            isSupabaseConfigured = isSupabaseConfigured,
            savedEmailHint = authState.adminEmail,
            errorMessage = authError,
            onBack = onBack,
            onSetupAdmin = onSetupAdmin,
            onLoginAdmin = onLoginAdmin,
            onClearError = onClearError
        )
    } else {
        AdminDashboardContent(
            adminEmail = authState.adminEmail,
            enquiries = enquiries,
            isSupabaseConfigured = isSupabaseConfigured,
            isSyncingCloud = isSyncingCloud,
            syncFeedback = syncFeedback,
            onBack = onBack,
            onSyncCloud = onSyncCloud,
            onOpenAttachment = onOpenAttachment,
            onToggleStatus = onToggleStatus,
            onDeleteEnquiry = onDeleteEnquiry,
            onMarkAllRead = onMarkAllRead,
            onLogout = onLogoutAdmin
        )
    }
}

@Composable
private fun AdminAuthGateScreen(
    isConfigured: Boolean,
    isSupabaseConfigured: Boolean,
    savedEmailHint: String,
    errorMessage: String?,
    onBack: () -> Unit,
    onSetupAdmin: (email: String, password: String, confirm: String) -> Unit,
    onLoginAdmin: (email: String, password: String) -> Unit,
    onClearError: () -> Unit
) {
    var email by rememberSaveable { mutableStateOf(if (savedEmailHint.isNotBlank()) savedEmailHint else BusinessContact.EMAIL) }
    var password by rememberSaveable { mutableStateOf("") }
    var confirmPassword by rememberSaveable { mutableStateOf("") }
    var showPassword by rememberSaveable { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 460.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(58.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_kashi_emblem),
                            contentDescription = stringResource(R.string.cd_brand_logo),
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                StatusPill(
                    text = if (isSupabaseConfigured) "SUPABASE CLOUD CONNECTED" else "LOCAL MODE • SUPABASE READY",
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = if (isSupabaseConfigured) "Supabase Admin Login"
                    else if (isConfigured) "Admin Portal Login"
                    else "Business Owner Setup",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = when {
                        isSupabaseConfigured -> "Sign in with your Supabase Admin email & password to sync enquiries and customer documents."
                        isConfigured -> "Authorized Kashi Tax staff only. Sign in to view and manage customer enquiries."
                        else -> "Create your private owner password once to protect the Customer Enquiry Dashboard."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = {
                        email = it
                        onClearError()
                    },
                    label = { Text("Admin Email") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_email_input")
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        password = it
                        onClearError()
                    },
                    label = { Text(if (isConfigured) "Admin Password" else "Create Password / PIN") },
                    singleLine = true,
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showPassword = !showPassword }) {
                            Icon(
                                imageVector = if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = if (showPassword) "Hide password" else "Show password"
                            )
                        }
                    },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_password_input")
                )

                if (!isConfigured) {
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = {
                            confirmPassword = it
                            onClearError()
                        },
                        label = { Text("Confirm Password / PIN") },
                        singleLine = true,
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_confirm_password_input")
                    )
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Button(
                    onClick = {
                        if (isConfigured) {
                            onLoginAdmin(email, password)
                        } else {
                            onSetupAdmin(email, password, confirmPassword)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("admin_auth_submit_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isConfigured) "Sign In to Dashboard" else "Create Admin & Enter")
                }

                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("admin_back_to_home_button"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Text("Back to Customer Home")
                }
            }
        }
    }
}

@Composable
private fun AdminDashboardContent(
    adminEmail: String,
    enquiries: List<EnquiryEntity>,
    isSupabaseConfigured: Boolean,
    isSyncingCloud: Boolean,
    syncFeedback: String?,
    onBack: () -> Unit,
    onSyncCloud: () -> Unit,
    onOpenAttachment: (com.example.util.PersistedAttachment) -> Unit,
    onToggleStatus: (EnquiryEntity) -> Unit,
    onDeleteEnquiry: (Long) -> Unit,
    onMarkAllRead: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedFilter by rememberSaveable { mutableStateOf(AdminFilter.ALL) }
    var enquiryPendingDelete by remember { mutableStateOf<EnquiryEntity?>(null) }
    var notificationsGranted by remember {
        mutableStateOf(NotificationHelper.hasNotificationPermission(context))
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationsGranted = granted
    }

    LaunchedEffect(enquiries.size) {
        onMarkAllRead()
    }

    val totalCount = enquiries.size
    val pendingCount = enquiries.count { it.status == EnquiryStatus.PENDING }
    val completedCount = enquiries.count { it.status == EnquiryStatus.COMPLETED }
    val urgentCount = enquiries.count { it.priority == EnquiryPriority.URGENT && it.status == EnquiryStatus.PENDING }

    val filteredEnquiries = remember(enquiries, searchQuery, selectedFilter) {
        enquiries.filter { item ->
            val matchesFilter = when (selectedFilter) {
                AdminFilter.ALL -> true
                AdminFilter.PENDING -> item.status == EnquiryStatus.PENDING
                AdminFilter.URGENT -> item.priority == EnquiryPriority.URGENT
                AdminFilter.COMPLETED -> item.status == EnquiryStatus.COMPLETED
            }
            val q = searchQuery.trim().lowercase()
            val matchesSearch = q.isEmpty() ||
                item.customerName.lowercase().contains(q) ||
                item.mobileNumber.contains(q) ||
                item.serviceName.lowercase().contains(q) ||
                item.referenceCode.lowercase().contains(q)
            matchesFilter && matchesSearch
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
                .imePadding(),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier.testTag("admin_dashboard_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = stringResource(R.string.cd_back),
                                    tint = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(Color(0xFFA8EECC), CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isSupabaseConfigured) "SUPABASE CLOUD • LIVE" else "ADMIN DASHBOARD • LOCAL",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Customer Enquiries",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = adminEmail,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onSyncCloud,
                                enabled = !isSyncingCloud,
                                modifier = Modifier.testTag("admin_sync_cloud_button")
                            ) {
                                if (isSyncingCloud) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Filled.Sync,
                                        contentDescription = "Sync with Supabase",
                                        tint = MaterialTheme.colorScheme.onPrimary
                                    )
                                }
                            }
                            IconButton(
                                onClick = onLogout,
                                modifier = Modifier.testTag("admin_logout_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Logout,
                                    contentDescription = "Sign out admin",
                                    tint = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    }
                }
            }

            if (!syncFeedback.isNullOrBlank()) {
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (isSupabaseConfigured) Icons.Filled.CloudDone else Icons.Filled.CloudSync,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = syncFeedback,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            if (!notificationsGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.NotificationsActive,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Enable Enquiry Alerts",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "Get notified instantly when a customer submits a new request.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                },
                                modifier = Modifier
                                    .height(44.dp)
                                    .testTag("admin_enable_notifications_button"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Enable")
                            }
                        }
                    }
                }
            }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        KpiMetricCard(
                            label = "Total Inflow",
                            value = totalCount.toString(),
                            accentColor = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        KpiMetricCard(
                            label = "Pending Action",
                            value = pendingCount.toString(),
                            accentColor = StatusAmberText,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        KpiMetricCard(
                            label = "Completed",
                            value = completedCount.toString(),
                            accentColor = StatusGreenText,
                            modifier = Modifier.weight(1f)
                        )
                        KpiMetricCard(
                            label = "Priority / Advance",
                            value = urgentCount.toString(),
                            accentColor = StatusUrgentText,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search customer name, mobile, ref #...") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .testTag("admin_search_input")
                    )

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(AdminFilter.entries) { filter ->
                            FilterChip(
                                selected = selectedFilter == filter,
                                onClick = { selectedFilter = filter },
                                label = { Text(filter.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier.testTag("admin_filter_${filter.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            if (filteredEnquiries.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Inbox,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = if (enquiries.isEmpty()) "No Customer Enquiries Yet" else "No Matching Enquiries",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (enquiries.isEmpty()) {
                                    "All requests submitted via Contact Us, GST Registration, and Online Forms will appear here immediately."
                                } else {
                                    "Try clearing your search or selecting a different status filter."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(filteredEnquiries, key = { it.id }) { enquiry ->
                    AdminEnquiryCard(
                        enquiry = enquiry,
                        onOpenAttachment = onOpenAttachment,
                        onToggleStatus = { onToggleStatus(enquiry) },
                        onCallCustomer = { IntentUtils.dialPhone(context, "+91${enquiry.mobileNumber}") },
                        onShareEnquiry = {
                            val summary = buildString {
                                appendLine("Kashi Tax & Business Services — Enquiry #${enquiry.referenceCode}")
                                appendLine("Customer: ${enquiry.customerName}")
                                appendLine("Mobile: +91 ${enquiry.mobileNumber}")
                                appendLine("Service: ${enquiry.serviceCategory} - ${enquiry.serviceName}")
                                appendLine("Status: ${enquiry.status}")
                                if (enquiry.message.isNotBlank()) appendLine("Notes: ${enquiry.message}")
                            }
                            DocumentStorageHelper.shareTextSummary(
                                context = context,
                                subject = "Enquiry #${enquiry.referenceCode} - ${enquiry.customerName}",
                                body = summary
                            )
                        },
                        onRequestDelete = { enquiryPendingDelete = enquiry },
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }
        }
    }

    enquiryPendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { enquiryPendingDelete = null },
            title = { Text("Delete Enquiry?") },
            text = {
                Text("Remove #${target.referenceCode} (${target.customerName}) permanently from the dashboard?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteEnquiry(target.id)
                        enquiryPendingDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { enquiryPendingDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun KpiMetricCard(
    label: String,
    value: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                color = accentColor,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdminEnquiryCard(
    enquiry: EnquiryEntity,
    onOpenAttachment: (com.example.util.PersistedAttachment) -> Unit,
    onToggleStatus: () -> Unit,
    onCallCustomer: () -> Unit,
    onShareEnquiry: () -> Unit,
    onRequestDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isCompleted = enquiry.status == EnquiryStatus.COMPLETED
    val decodedDocs = remember(enquiry.attachedDocuments) {
        DocumentStorageHelper.decodeAttachments(enquiry.attachedDocuments)
    }
    val decodedPaymentProof = remember(enquiry.paymentProofName) {
        DocumentStorageHelper.decodeSingle(enquiry.paymentProofName)
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPill(
                        text = "#${enquiry.referenceCode}",
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                    if (enquiry.isSyncedToCloud) {
                        StatusPill(
                            text = "CLOUD",
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = MaterialTheme.colorScheme.primary
                        )
                    }
                    if (enquiry.priority == EnquiryPriority.URGENT) {
                        StatusPill(
                            text = "PRIORITY",
                            containerColor = StatusUrgentBg,
                            contentColor = StatusUrgentText
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusPill(
                        text = if (isCompleted) "COMPLETED" else "PENDING",
                        containerColor = if (isCompleted) StatusGreenBg else StatusAmberBg,
                        contentColor = if (isCompleted) StatusGreenText else StatusAmberText
                    )
                    IconButton(
                        onClick = onShareEnquiry,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Share,
                            contentDescription = "Share enquiry",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onRequestDelete,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Delete enquiry",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = enquiry.customerName,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "+91 ${enquiry.mobileNumber} • ${IntentUtils.formatTimestamp(enquiry.createdAtMillis)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "${enquiry.serviceCategory} — ${enquiry.serviceName}",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (enquiry.message.isNotBlank()) {
                        Text(
                            text = enquiry.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (decodedDocs.isNotEmpty()) {
                        Text(
                            text = "ATTACHED DOCUMENTS (TAP TO VIEW)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            decodedDocs.forEach { doc ->
                                AssistChip(
                                    onClick = { onOpenAttachment(doc) },
                                    label = { Text(doc.displayName, maxLines = 1) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Filled.AttachFile,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                )
                            }
                        }
                    }
                    if (enquiry.paymentMode != PaymentMode.NONE) {
                        val modeLabel = if (enquiry.paymentMode == PaymentMode.PAY_ADVANCE) {
                            "Payment: Advance Selected (₹999)"
                        } else {
                            "Payment: Pay After Work"
                        }
                        Text(
                            text = modeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (decodedPaymentProof != null) {
                            AssistChip(
                                onClick = { onOpenAttachment(decodedPaymentProof) },
                                label = { Text("View Payment Proof: ${decodedPaymentProof.displayName}", maxLines = 1) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Filled.Receipt,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onToggleStatus,
                    modifier = Modifier
                        .weight(1.2f)
                        .height(48.dp)
                        .testTag("admin_toggle_status_${enquiry.id}"),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Icon(
                        imageVector = if (isCompleted) Icons.Filled.PendingActions else Icons.Filled.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isCompleted) "Mark Pending" else "Mark Completed")
                }

                Button(
                    onClick = onCallCustomer,
                    modifier = Modifier
                        .weight(0.9f)
                        .height(48.dp)
                        .testTag("admin_call_customer_${enquiry.id}"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(
                        imageVector = Icons.Filled.Call,
                        contentDescription = stringResource(R.string.cd_call_customer),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Call")
                }
            }
        }
    }
}
