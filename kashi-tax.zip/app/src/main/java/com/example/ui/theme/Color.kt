package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vedic Corporate Modern — Deep Forest Green & Pristine Alabaster Palette
val ForestPrimary = Color(0xFF003521)
val ForestPrimaryContainer = Color(0xFF0E4D34)
val ForestOnPrimary = Color(0xFFFFFFFF)
val ForestOnPrimaryContainer = Color(0xFFA8EECC)

val EmeraldSecondary = Color(0xFF246A4F)
val EmeraldSecondaryContainer = Color(0xFFC2F5DC)
val EmeraldOnSecondary = Color(0xFFFFFFFF)
val EmeraldOnSecondaryContainer = Color(0xFF002114)

val SageTertiary = Color(0xFF396553)
val SageTertiaryContainer = Color(0xFFBCECD6)
val SageOnTertiary = Color(0xFFFFFFFF)
val SageOnTertiaryContainer = Color(0xFF002116)

val SurfaceAlabaster = Color(0xFFFAF8FF)
val SurfacePureWhite = Color(0xFFFFFFFF)
val SurfaceContainerLow = Color(0xFFF3F6F4)
val SurfaceContainer = Color(0xFFEBEFED)
val SurfaceContainerHigh = Color(0xFFE2E8E5)
val SurfaceContainerHighest = Color(0xFFD7DFDB)

val InkOnSurface = Color(0xFF131B2E)
val InkOnSurfaceVariant = Color(0xFF475467)
val OutlineSubtle = Color(0xFFC7D3CE)
val OutlineVariantHairline = Color(0xFFDEE6E2)

val StatusError = Color(0xFFBA1A1A)
val StatusErrorContainer = Color(0xFFFFDAD6)
val StatusOnError = Color(0xFFFFFFFF)
val StatusOnErrorContainer = Color(0xFF410002)

val StatusAmberBg = Color(0xFFFEF3C7)
val StatusAmberText = Color(0xFF92400E)
val StatusGreenBg = Color(0xFFDCFCE7)
val StatusGreenText = Color(0xFF166534)
val StatusUrgentBg = Color(0xFFFEE2E2)
val StatusUrgentText = Color(0xFF991B1B)

// Dark Theme Counterparts
val DarkPrimary = Color(0xFF8CD6B4)
val DarkOnPrimary = Color(0xFF003824)
val DarkPrimaryContainer = Color(0xFF0E4D34)
val DarkOnPrimaryContainer = Color(0xFFA8EECC)

val DarkSecondary = Color(0xFFA6D2BD)
val DarkOnSecondary = Color(0xFF0E3727)
val DarkSecondaryContainer = Color(0xFF1E4E3B)
val DarkOnSecondaryContainer = Color(0xFFC2F5DC)

val DarkSurface = Color(0xFF0F1613)
val DarkSurfaceContainerLow = Color(0xFF151E1A)
val DarkSurfaceContainer = Color(0xFF1A2520)
val DarkSurfaceContainerHigh = Color(0xFF223029)
val DarkOnSurface = Color(0xFFE6EFEA)
val DarkOnSurfaceVariant = Color(0xFFB5C4BC)
val DarkOutline = Color(0xFF3E4F47)
val DarkOutlineVariant = Color(0xFF2B3A33)
