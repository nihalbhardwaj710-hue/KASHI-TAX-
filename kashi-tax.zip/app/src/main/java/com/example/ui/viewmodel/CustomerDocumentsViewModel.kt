package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.CustomerAuthPreferences
import com.example.data.local.CustomerAuthSession
import com.example.data.remote.CustomerDocumentDto
import com.example.data.repository.CustomerAuthResult
import com.example.data.repository.CustomerDocumentRepository
import com.example.data.repository.VaultDocumentCategory
import com.example.util.DocumentStorageHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class CustomerDocumentsViewModel(
    private val application: Application,
    private val repository: CustomerDocumentRepository
) : ViewModel() {

    val isSupabaseConfigured: Boolean
        get() = repository.isSupabaseConfigured

    val session: StateFlow<CustomerAuthSession> = repository.sessionFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = CustomerAuthSession()
        )

    private val _documents = MutableStateFlow<List<CustomerDocumentDto>>(emptyList())
    val documents: StateFlow<List<CustomerDocumentDto>> = _documents.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isUploading = MutableStateFlow(false)
    val isUploading: StateFlow<Boolean> = _isUploading.asStateFlow()

    private val _isAuthBusy = MutableStateFlow(false)
    val isAuthBusy: StateFlow<Boolean> = _isAuthBusy.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    fun signIn(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _errorMessage.value = "Kripya apna email aur password dono bharein."
            return
        }
        viewModelScope.launch {
            _isAuthBusy.value = true
            _errorMessage.value = null
            _statusMessage.value = null
            try {
                when (val res = repository.signIn(email, password)) {
                    is CustomerAuthResult.Authenticated -> {
                        _statusMessage.value = res.message
                        refreshDocuments()
                    }
                    is CustomerAuthResult.VerificationRequired -> {
                        _statusMessage.value = res.message
                    }
                    is CustomerAuthResult.Error -> {
                        _errorMessage.value = res.message
                    }
                }
            } finally {
                _isAuthBusy.value = false
            }
        }
    }

    fun signUp(email: String, password: String, confirmPassword: String) {
        when {
            email.isBlank() || !email.contains("@") -> {
                _errorMessage.value = "Kripya sahi email address dalein."
                return
            }
            password.length < 6 -> {
                _errorMessage.value = "Password kam se kam 6 characters ka hona chahiye."
                return
            }
            password != confirmPassword -> {
                _errorMessage.value = "Dono passwords match nahi kar rahe."
                return
            }
        }
        viewModelScope.launch {
            _isAuthBusy.value = true
            _errorMessage.value = null
            _statusMessage.value = null
            try {
                when (val res = repository.signUp(email, password)) {
                    is CustomerAuthResult.Authenticated -> {
                        _statusMessage.value = res.message
                        refreshDocuments()
                    }
                    is CustomerAuthResult.VerificationRequired -> {
                        _statusMessage.value = res.message
                    }
                    is CustomerAuthResult.Error -> {
                        _errorMessage.value = res.message
                    }
                }
            } finally {
                _isAuthBusy.value = false
            }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            repository.signOut()
            _documents.value = emptyList()
            _statusMessage.value = null
            _errorMessage.value = null
        }
    }

    fun refreshDocuments() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                repository.fetchMyDocuments()
                    .onSuccess { list -> _documents.value = list }
                    .onFailure { err -> _errorMessage.value = err.message ?: "Documents load nahi ho sake." }
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun uploadUris(uris: List<Uri>, category: VaultDocumentCategory) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _isUploading.value = true
            _errorMessage.value = null
            _statusMessage.value = null
            var uploadedCount = 0
            try {
                for (uri in uris) {
                    repository.uploadUriDocument(uri, category)
                        .onSuccess { uploadedCount++ }
                        .onFailure { err -> _errorMessage.value = err.message }
                }
                if (uploadedCount > 0) {
                    _statusMessage.value = "$uploadedCount ${category.displayLabel} document(s) safely private vault me upload ho gaye."
                    refreshDocuments()
                }
            } finally {
                _isUploading.value = false
            }
        }
    }

    fun uploadCameraPhoto(tempFile: File, category: VaultDocumentCategory) {
        viewModelScope.launch {
            _isUploading.value = true
            _errorMessage.value = null
            _statusMessage.value = null
            try {
                repository.uploadCameraFile(tempFile, category)
                    .onSuccess {
                        _statusMessage.value = "${category.displayLabel} photo safely private vault me upload ho gayi."
                        refreshDocuments()
                    }
                    .onFailure { err ->
                        _errorMessage.value = err.message ?: "Photo upload fail hui."
                    }
            } finally {
                _isUploading.value = false
            }
        }
    }

    fun viewDocument(activityContext: Context, doc: CustomerDocumentDto) {
        viewModelScope.launch {
            _errorMessage.value = null
            repository.createSignedUrl(doc.storagePath)
                .onSuccess { signedUrl ->
                    DocumentStorageHelper.openRemoteDocumentUrl(activityContext, signedUrl)
                }
                .onFailure { err ->
                    _errorMessage.value = err.message ?: "Document open nahi ho saka."
                }
        }
    }

    fun downloadDocument(doc: CustomerDocumentDto) {
        viewModelScope.launch {
            _errorMessage.value = null
            repository.downloadDocument(doc)
                .onSuccess { msg ->
                    _statusMessage.value = msg
                    Toast.makeText(application, msg, Toast.LENGTH_LONG).show()
                }
                .onFailure { err ->
                    _errorMessage.value = err.message ?: "Document download fail hua."
                }
        }
    }

    fun deleteDocument(doc: CustomerDocumentDto) {
        viewModelScope.launch {
            _errorMessage.value = null
            repository.deleteDocument(doc)
                .onSuccess {
                    _documents.value = _documents.value.filterNot { it.id == doc.id }
                    _statusMessage.value = "${doc.fileName} private vault se delete ho gaya."
                }
                .onFailure { err ->
                    _errorMessage.value = err.message ?: "Document delete nahi ho saka."
                }
        }
    }

    fun clearMessages() {
        _errorMessage.value = null
        _statusMessage.value = null
    }

    companion object {
        fun factory(application: Application): ViewModelProvider.Factory {
            return object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val prefs = CustomerAuthPreferences(application)
                    val repo = CustomerDocumentRepository(application, prefs)
                    return CustomerDocumentsViewModel(application, repo) as T
                }
            }
        }
    }
}
