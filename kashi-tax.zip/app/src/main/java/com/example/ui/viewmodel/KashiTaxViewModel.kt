package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.local.AdminAuthSnapshot
import com.example.data.local.AdminPreferences
import com.example.data.local.AppDatabase
import com.example.data.local.CustomerAuthPreferences
import com.example.data.local.EnquiryEntity
import com.example.data.local.PaymentMode
import com.example.data.repository.AdminLoginResult
import com.example.data.repository.EnquiryRepository
import com.example.util.DocumentStorageHelper
import com.example.util.NotificationHelper
import com.example.util.PersistedAttachment
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SubmissionConfirmation(
    val referenceCode: String,
    val serviceName: String,
    val message: String
)

class KashiTaxViewModel(
    private val application: Application,
    private val repository: EnquiryRepository
) : ViewModel() {

    val isSupabaseConfigured: Boolean
        get() = repository.isSupabaseConfigured

    val enquiries: StateFlow<List<EnquiryEntity>> = repository.allEnquiries
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val unreadCount: StateFlow<Int> = repository.unreadCount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    val adminAuthState: StateFlow<AdminAuthSnapshot> = repository.adminAuthState
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AdminAuthSnapshot()
        )

    private val _submissionConfirmation = MutableStateFlow<SubmissionConfirmation?>(null)
    val submissionConfirmation: StateFlow<SubmissionConfirmation?> = _submissionConfirmation.asStateFlow()

    private val _adminAuthError = MutableStateFlow<String?>(null)
    val adminAuthError: StateFlow<String?> = _adminAuthError.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    private val _isSyncingCloud = MutableStateFlow(false)
    val isSyncingCloud: StateFlow<Boolean> = _isSyncingCloud.asStateFlow()

    private val _syncFeedback = MutableStateFlow<String?>(null)
    val syncFeedback: StateFlow<String?> = _syncFeedback.asStateFlow()

    fun submitContactEnquiry(
        customerName: String,
        mobileNumber: String,
        serviceName: String,
        message: String,
        serviceCategory: String = inferCategory(serviceName),
        attachedDocuments: List<PersistedAttachment> = emptyList()
    ) {
        viewModelScope.launch {
            _isSubmitting.value = true
            try {
                val created = repository.submitEnquiry(
                    customerName = customerName,
                    mobileNumber = mobileNumber,
                    serviceCategory = serviceCategory,
                    serviceName = serviceName,
                    message = message.ifBlank { "Callback requested for $serviceName" },
                    encodedDocuments = DocumentStorageHelper.encodeAttachments(attachedDocuments),
                    prefix = "KTS"
                )
                NotificationHelper.notifyNewEnquiry(
                    context = application,
                    referenceCode = created.referenceCode,
                    customerName = created.customerName,
                    serviceName = created.serviceName
                )
                _submissionConfirmation.value = SubmissionConfirmation(
                    referenceCode = created.referenceCode,
                    serviceName = created.serviceName,
                    message = application.getString(R.string.contact_confirmation_message)
                )
            } finally {
                _isSubmitting.value = false
            }
        }
    }

    fun submitGstRegistration(
        customerName: String,
        mobileNumber: String,
        notes: String,
        attachedDocuments: List<PersistedAttachment>,
        paymentMode: String,
        paymentProof: PersistedAttachment?
    ) {
        viewModelScope.launch {
            _isSubmitting.value = true
            try {
                val summaryNote = buildString {
                    if (notes.isNotBlank()) append(notes.trim())
                    else append("New GST Registration application submitted via mobile app.")
                    if (paymentMode == PaymentMode.PAY_ADVANCE) {
                        append(" [Advance Payment Selected]")
                    } else {
                        append(" [Pay After Work Selected]")
                    }
                }
                val created = repository.submitEnquiry(
                    customerName = customerName,
                    mobileNumber = mobileNumber,
                    serviceCategory = "GST Services",
                    serviceName = "New GST Registration",
                    message = summaryNote,
                    encodedDocuments = DocumentStorageHelper.encodeAttachments(attachedDocuments),
                    paymentMode = paymentMode,
                    encodedPaymentProof = DocumentStorageHelper.encodeSingle(paymentProof),
                    prefix = "GST-REG"
                )
                NotificationHelper.notifyNewEnquiry(
                    context = application,
                    referenceCode = created.referenceCode,
                    customerName = created.customerName,
                    serviceName = created.serviceName
                )
                _submissionConfirmation.value = SubmissionConfirmation(
                    referenceCode = created.referenceCode,
                    serviceName = created.serviceName,
                    message = application.getString(R.string.contact_confirmation_message)
                )
            } finally {
                _isSubmitting.value = false
            }
        }
    }

    fun submitOnlineFormRequest(
        customerName: String,
        mobileNumber: String,
        formTitle: String,
        notes: String,
        attachedDocuments: List<PersistedAttachment>
    ) {
        viewModelScope.launch {
            _isSubmitting.value = true
            try {
                val created = repository.submitEnquiry(
                    customerName = customerName,
                    mobileNumber = mobileNumber,
                    serviceCategory = "Online Forms",
                    serviceName = formTitle,
                    message = notes.ifBlank { "Assisted online form application for $formTitle" },
                    encodedDocuments = DocumentStorageHelper.encodeAttachments(attachedDocuments),
                    prefix = "FRM"
                )
                NotificationHelper.notifyNewEnquiry(
                    context = application,
                    referenceCode = created.referenceCode,
                    customerName = created.customerName,
                    serviceName = created.serviceName
                )
                _submissionConfirmation.value = SubmissionConfirmation(
                    referenceCode = created.referenceCode,
                    serviceName = created.serviceName,
                    message = application.getString(R.string.contact_confirmation_message)
                )
            } finally {
                _isSubmitting.value = false
            }
        }
    }

    fun clearSubmissionConfirmation() {
        _submissionConfirmation.value = null
    }

    fun syncCloudEnquiries() {
        if (!repository.isSupabaseConfigured) {
            _syncFeedback.value = "Add SUPABASE_URL & SUPABASE_ANON_KEY in AI Studio Secrets to enable cloud sync."
            return
        }
        viewModelScope.launch {
            _isSyncingCloud.value = true
            _syncFeedback.value = null
            try {
                val result = repository.syncWithSupabase()
                result.onSuccess { count ->
                    _syncFeedback.value = "Synced $count enquiries from Supabase."
                }.onFailure { err ->
                    _syncFeedback.value = err.message ?: "Cloud sync failed."
                }
            } finally {
                _isSyncingCloud.value = false
            }
        }
    }

    fun openAttachment(activityContext: Context, attachment: PersistedAttachment) {
        val openedLocally = DocumentStorageHelper.openStoredDocument(activityContext, attachment)
        if (openedLocally) return

        viewModelScope.launch {
            val signedUrl = repository.getSignedDocumentUrl(attachment)
            if (!signedUrl.isNullOrBlank()) {
                DocumentStorageHelper.openRemoteDocumentUrl(activityContext, signedUrl)
            } else {
                Toast.makeText(activityContext, "Unable to open document (${attachment.displayName})", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun toggleEnquiryStatus(enquiry: EnquiryEntity) {
        viewModelScope.launch {
            repository.toggleEnquiryStatus(enquiry)
        }
    }

    fun markAllEnquiriesRead() {
        viewModelScope.launch {
            repository.markAllRead()
        }
    }

    fun deleteEnquiry(id: Long) {
        viewModelScope.launch {
            repository.deleteEnquiry(id)
        }
    }

    fun setupAdminAccount(email: String, password: String, confirmPassword: String) {
        val cleanEmail = email.trim()
        val cleanPass = password.trim()
        when {
            cleanEmail.isBlank() || !cleanEmail.contains("@") -> {
                _adminAuthError.value = "Please enter a valid admin email address."
                return
            }
            cleanPass.length < 4 -> {
                _adminAuthError.value = "Password or PIN must be at least 4 characters."
                return
            }
            cleanPass != confirmPassword.trim() -> {
                _adminAuthError.value = "Passwords do not match."
                return
            }
        }
        viewModelScope.launch {
            _adminAuthError.value = null
            repository.setupLocalAdminAccount(cleanEmail, cleanPass)
            repository.markAllRead()
        }
    }

    fun loginAdmin(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _adminAuthError.value = "Enter both admin email and password."
            return
        }
        viewModelScope.launch {
            when (val result = repository.loginAdmin(email, password)) {
                is AdminLoginResult.Success -> {
                    _adminAuthError.value = null
                    repository.markAllRead()
                    if (repository.isSupabaseConfigured) {
                        syncCloudEnquiries()
                    }
                }
                is AdminLoginResult.Error -> {
                    _adminAuthError.value = result.message
                }
            }
        }
    }

    fun logoutAdmin() {
        viewModelScope.launch {
            repository.logoutAdmin()
            _syncFeedback.value = null
        }
    }

    fun clearAdminError() {
        _adminAuthError.value = null
    }

    private fun inferCategory(serviceName: String): String {
        val lower = serviceName.lowercase()
        return when {
            lower.contains("gst") -> "GST Services"
            lower.contains("itr") || lower.contains("balance") || lower.contains("tax") -> "ITR & Accounts"
            lower.contains("roc") || lower.contains("company") || lower.contains("aoc") -> "ROC & Corporate"
            lower.contains("aadhaar") || lower.contains("certificate") || lower.contains("ration") ||
                lower.contains("ayushman") || lower.contains("voter") || lower.contains("passport") ||
                lower.contains("driving") -> "Govt Documents"
            lower.contains("form") || lower.contains("job") || lower.contains("scholarship") ||
                lower.contains("admission") || lower.contains("pan") -> "Online Forms"
            else -> "General Enquiry"
        }
    }

    companion object {
        fun factory(application: Application): ViewModelProvider.Factory {
            return object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val database = AppDatabase.getInstance(application)
                    val prefs = AdminPreferences(application)
                    val customerPrefs = CustomerAuthPreferences(application)
                    val repository = EnquiryRepository(application, database.enquiryDao(), prefs, customerPrefs)
                    return KashiTaxViewModel(application, repository) as T
                }
            }
        }
    }
}
