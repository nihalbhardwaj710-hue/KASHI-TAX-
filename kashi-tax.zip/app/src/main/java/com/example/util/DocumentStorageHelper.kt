package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

data class PersistedAttachment(
    val displayName: String,
    val storedFileName: String
)

object DocumentStorageHelper {

    private const val UPLOADED_DOCS_DIR = "uploaded_docs"
    private const val CAMERA_CAPTURES_DIR = "camera_captures"
    private const val ENTRY_DELIMITER = "||"
    private const val PAIR_DELIMITER = "::"

    fun createCameraCaptureTarget(context: Context): Pair<Uri, File> {
        val dir = File(context.cacheDir, CAMERA_CAPTURES_DIR).apply { mkdirs() }
        val fileName = "IMG_${System.currentTimeMillis()}.jpg"
        val file = File(dir, fileName)
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        return uri to file
    }

    suspend fun persistUri(context: Context, uri: Uri): PersistedAttachment? = withContext(Dispatchers.IO) {
        runCatching {
            val displayName = IntentUtils.resolveDisplayName(context, uri)
            val mimeType = context.contentResolver.getType(uri)
            val extFromName = displayName.substringAfterLast('.', "").lowercase()
            val ext = extFromName.takeIf { it.isNotBlank() && it.length <= 5 }
                ?: MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)
                ?: "bin"

            val safeStoredName = "${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.$ext"
            val targetDir = File(context.filesDir, UPLOADED_DOCS_DIR).apply { mkdirs() }
            val targetFile = File(targetDir, safeStoredName)

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext null

            PersistedAttachment(
                displayName = displayName,
                storedFileName = safeStoredName
            )
        }.getOrNull()
    }

    suspend fun persistCameraFile(context: Context, tempFile: File, labelPrefix: String): PersistedAttachment? =
        withContext(Dispatchers.IO) {
            runCatching {
                if (!tempFile.exists() || tempFile.length() == 0L) return@withContext null
                val targetDir = File(context.filesDir, UPLOADED_DOCS_DIR).apply { mkdirs() }
                val storedName = "${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg"
                val destFile = File(targetDir, storedName)
                tempFile.copyTo(destFile, overwrite = true)
                tempFile.delete()
                PersistedAttachment(
                    displayName = "${labelPrefix}_${storedName.takeLast(10)}",
                    storedFileName = storedName
                )
            }.getOrNull()
        }

    fun encodeAttachments(attachments: List<PersistedAttachment>): String {
        return attachments.joinToString(ENTRY_DELIMITER) { item ->
            "${item.displayName.replace(ENTRY_DELIMITER, " ").replace(PAIR_DELIMITER, " ")}$PAIR_DELIMITER${item.storedFileName}"
        }
    }

    fun decodeAttachments(raw: String): List<PersistedAttachment> {
        if (raw.isBlank()) return emptyList()
        return raw.split(ENTRY_DELIMITER)
            .mapNotNull { token ->
                val trimmed = token.trim()
                if (trimmed.isEmpty()) return@mapNotNull null
                if (trimmed.contains(PAIR_DELIMITER)) {
                    val parts = trimmed.split(PAIR_DELIMITER, limit = 2)
                    PersistedAttachment(
                        displayName = parts[0].trim(),
                        storedFileName = parts.getOrElse(1) { "" }.trim()
                    )
                } else {
                    PersistedAttachment(displayName = trimmed, storedFileName = "")
                }
            }
    }

    fun encodeSingle(attachment: PersistedAttachment?): String {
        if (attachment == null) return ""
        return encodeAttachments(listOf(attachment))
    }

    fun decodeSingle(raw: String): PersistedAttachment? {
        return decodeAttachments(raw).firstOrNull()
    }

    fun getUploadedFile(context: Context, storedFileName: String): File? {
        if (storedFileName.isBlank()) return null
        val file = File(File(context.filesDir, UPLOADED_DOCS_DIR), storedFileName)
        return if (file.exists()) file else null
    }

    fun guessMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    fun openStoredDocument(context: Context, attachment: PersistedAttachment): Boolean {
        if (attachment.storedFileName.isBlank()) {
            Toast.makeText(context, "Document reference: ${attachment.displayName}", Toast.LENGTH_SHORT).show()
            return true
        }
        val file = getUploadedFile(context, attachment.storedFileName) ?: return false
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val mimeType = guessMimeType(file.name)

        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching {
            context.startActivity(Intent.createChooser(viewIntent, "Open ${attachment.displayName}"))
        }.onFailure {
            Toast.makeText(context, "No app available to open this file type", Toast.LENGTH_SHORT).show()
        }
        return true
    }

    fun openRemoteDocumentUrl(context: Context, url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        runCatching {
            context.startActivity(intent)
        }.onFailure {
            Toast.makeText(context, "Unable to open cloud document", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareTextSummary(context: Context, subject: String, body: String) {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
        }
        runCatching {
            context.startActivity(Intent.createChooser(sendIntent, "Share Enquiry Summary"))
        }.onFailure {
            Toast.makeText(context, "Unable to open share sheet", Toast.LENGTH_SHORT).show()
        }
    }
}
