---
name: Vedic Corporate Modern
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#404943'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#707973'
  outline-variant: '#c0c9c1'
  surface-tint: '#2f694e'
  primary: '#003521'
  on-primary: '#ffffff'
  primary-container: '#0e4d34'
  on-primary-container: '#82bd9d'
  inverse-primary: '#97d4b2'
  secondary: '#246a4f'
  on-secondary: '#ffffff'
  secondary-container: '#a8eecc'
  on-secondary-container: '#296e53'
  tertiary: '#003522'
  on-tertiary: '#ffffff'
  tertiary-container: '#004e34'
  on-tertiary-container: '#2fc88e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b3f0cd'
  primary-fixed-dim: '#97d4b2'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#135137'
  secondary-fixed: '#abf1cf'
  secondary-fixed-dim: '#90d5b4'
  on-secondary-fixed: '#002115'
  on-secondary-fixed-variant: '#005139'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  title-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a high-trust, authoritative, and frictionless financial ecosystem tailored for Indian corporate compliance, taxation, and business consultancy. The aesthetic bridges traditional fiduciary gravitas with the streamlined efficiency of modern fintech.

### Target Audience & Psychological Intent
- **Audience:** Indian MSME founders, enterprise CFOs, chartered accountants, and individual tax assessees navigating GST filings, corporate governance, auditing, and ROC compliances.
- **Emotional Response:** Unwavering institutional security, regulatory clarity, transparent precision, and modern accessibility.

### Design Movement & Visual Philosophy
The design language adopts a disciplined synthesis of **Corporate Modernism** and **Refined Android Material 3 ergonomics**. It prioritizes extreme data legibility over ornamentation:
- Flat architectural cards with structural hierarchy.
- Crisp boundary delineation using cool grey borders to segment dense fiscal data.
- Intentional touch surfaces tuned to mobile ergonomic thumb zones, eliminating accidental actions on critical compliance flows.

## Colors

The color palette centers around institutional permanence and fiscal health, avoiding generic blue fintech tropes in favor of deep, sovereign forest greens and sharp precision accents.

### Palette Architecture
- **Primary (`#0E4D34`):** Deep Corporate Forest Green serves as the primary anchor for app bars, primary action buttons, key balance summaries, and institutional badges.
- **Secondary (`#135D43`):** Medium Pine Forest Green handles interactive secondary buttons, tonal icon containers, and segmented controls.
- **Tertiary Accent (`#10B981`):** Vivid Emerald Accent provides contextual feedback for positive fiscal reconciliation, compliance verification markers, success toasts, and forward indicators.
- **Neutral Foreground (`#0F172A`):** Deep Slate Charcoal drives all primary typography, high-priority monetary values, and structural icons, guaranteeing AAA contrast ratios across white surfaces.
- **Surface & Backgrounds:** The base canvas operates on pure white (`#FFFFFF`), while component cards utilize an ultra-subtle cool grey-tinted card background (`#F8FAF9`) framed with structural hairline strokes (`#E5E9E7`).
- **Semantic Signals:** Warning and attention states utilize amber-tinted ocher (`#B45309`) and critical error/audit flags utilize crisp crimson (`#DC2626`).

## Typography

The design system standardizes exclusively on **Inter** to ensure maximum typographic neutrality, rock-solid vertical metric consistency, and exceptional rendering of complex alphanumeric strings (such as PAN, GSTIN, TAN, and ITR acknowledgement tokens).

### Typographic Hierarchy & Guidelines
- **Financial Figures & Metrics:** Large currency totals (INR) must utilize tabular numbers (`tnum`) in weights 600 or 700 with negative tracking (`-0.02em`) to retain a unified tabular rhythm in ledgers and balance sheets.
- **Headlines:** Reserved for portal onboarding, dashboard section titles, and monthly tax summaries. Kept tight to prevent excessive multiline wrapping on narrow Android viewports.
- **Body:** Built at strict 14px and 16px standards to ensure flawless reading of advisory disclosures, statutory deadlines, and tax notices.
- **Labels & Tags:** Uppercase or small title-cased labels are applied to status badges (e.g., "GST FILED", "PENDING AUDIT", "TDS RECONCILED") using `label-sm` with tight letter spacing for instant visual recognition.

## Layout & Spacing

The layout is built for an Android-first mobile native environment using an adaptable 4-column layout on standard phones expanding to an 8-column grid on small foldables and tablets.

### Mobile Ergonomics & Grid Rules
- **Margins & Gutters:** Base screen canvas adopts fixed `16px` (`1rem`) horizontal outer margins to maximize data-display width on compact devices. Grid gutters stay consistent at `16px`.
- **Thumb Zone Optimization:** Primary actions, document upload triggers, and quarterly filing switches sit anchored in the lower 40% of the screen viewport. Sticky bottom app bars and action sheets host primary operational triggers.
- **Vertical Metric Rhythm:** Spacing between interrelated data attributes utilizes `space-xs` (4px) or `space-sm` (8px). Structural cards and form sections separate via `space-md` (16px) or `space-lg` (24px).
- **Responsive Adaptations:**
  - **Phone (<600dp):** Single-column stacked card feed; full-width action sheets.
  - **Foldable / Tablet (600dp - 840dp):** Two-column split-pane master-detail view with persistent navigation rail.

## Elevation & Depth

To communicate trust and fiscal integrity, the design system avoids heavy shadows, floating skeuomorphism, and muddy blurs. Visual elevation is attained predominantly through **low-contrast architectural outlines and subtle tonal layering**.

### Elevation Scale
- **Level 0 (Flat Surface / Canvas):** Pure white (`#FFFFFF`) canvas for structural backgrounds and page bodies.
- **Level 1 (Card & Content Blocks):** Tonal surface `#F8FAF9` encased with a crisp 1px solid border of `#E5E9E7`. Zero shadow blur. This delineates ledger entries, filing progress cards, and client profile modules.
- **Level 2 (Dropdowns, Menus & Tooltips):** Surface `#FFFFFF` bordered with `#E5E9E7`, paired with a diffuse ambient shadow: `box-shadow: 0px 4px 12px rgba(15, 23, 42, 0.06)`.
- **Level 3 (Modal Bottom Sheets & Dialogs):** Surface `#FFFFFF` layered over an scrim of `rgba(15, 23, 42, 0.40)`, with a top border hairline of `#E5E9E7` and a soft directional lift: `box-shadow: 0px -4px 20px rgba(15, 23, 42, 0.08)`.
- **Scrolled App Bar State:** Upon vertical scrolling, top bars transition from `#FFFFFF` flat to `#FFFFFF` with a 1px border-bottom in `#E5E9E7` without drop shadows.

## Shapes

The design system executes a restrained, crisp **Soft (`roundedness: 1`)** geometry. This reinforces an enterprise standard suitable for legal, tax, and auditing workflows, distancing the interface from casual consumer apps.

### Corner Radius Tokens
- **Base Components (Inputs, Small Badges, Chips):** `4px` (`0.25rem`). Maintains sharp, structured lines across data-heavy forms.
- **Cards & Data Panels (`rounded-lg`):** `8px` (`0.5rem`). Applied to summary boxes, tax liability breakdowns, and document preview tiles.
- **Sheets & Modal Containers (`rounded-xl`):** `12px` (`0.75rem`). Applied exclusively to the top corners of Android modal bottom sheets.
- **System Buttons:** `6px` for standard primary/secondary buttons; pill forms are strictly avoided to preserve technical authority.

## Components

### Buttons & Interactive Controls
- **Touch Target:** Strict adherence to Android M3 standard: minimum touch target of 48×48dp, even if visible surface is smaller.
- **Primary Button:** Deep Forest Green (`#0E4D34`) background, pure white text (`Inter 14px Weight 600`), 6px radius, vertical height 48px. Active state transitions to `#135D43`.
- **Secondary Button:** Surface `#FFFFFF`, 1px stroke `#0E4D34`, text color `#0E4D34`.
- **Tertiary / Ghost Button:** Transparent background, text `#135D43`, zero border, used for ancillary actions like "View Past Challan".

### Input Fields & Verification Controls
- **Default State:** Clean `#FFFFFF` fill with a 1px boundary of `#E5E9E7`. Label positioned via floating pattern in `label-sm` slate charcoal (`#0F172A`).
- **Focus State:** Stroke color transitions to deep corporate green (`#0E4D34`) with a 1.5px border-width. No glow rings.
- **Specialized Inputs:** PAN/GSTIN inputs automatically enforce uppercase character transformation and provide a trailing inline "Verify" button or instant verified green checkmark (`#10B981`).

### Cards & Ledger Modules
- **Compliance Card:** Built with `#F8FAF9` fill and a 1px outline of `#E5E9E7`. Top section displays compliance category (e.g., "GSTR-3B") alongside an emerald pill indicator for completed actions or an amber indicator for approaching deadlines.
- **Metric Cards:** Dual-split panels showing "Net Taxable Amount" vs "Input Tax Credit (ITC)" divided by a hairline vertical separator `#E5E9E7`.

### Chips & Filter Tabs
- **Filter Chips:** 32px height, 4px corner radius. Inactive: `#FFFFFF` fill with 1px border `#E5E9E7`, text `#0F172A`. Active: `#0E4D34` fill, text `#FFFFFF`, border `#0E4D34`.
- **Status Chips:** Flat micro-badges (`label-sm`) using 10% tint backgrounds of primary emerald (`#10B981`) or slate (`#0F172A`) paired with corresponding 100% saturation text.

### Checkboxes, Radios & Switches
- **Checkboxes & Radios:** Sharp 3px rounded borders on checkboxes; `#0E4D34` fill when checked with white glyph. Unchecked states hold a 1.5px `#E5E9E7` border.
- **Switches:** Android Material 3 switch track: 32dp height, thumb 24dp. Active track `#0E4D34` with white thumb. Inactive track `#E5E9E7` with slate charcoal thumb.

### Domain-Specific Components
- **Challan Status Stepper:** A vertical multi-stage indicator tracking "Drafted → Client Approved → Tax Paid → Acknowledgement Generated" using 2px connecting lines in `#E5E9E7` populated by emerald node badges.
- **Document Locker Card:** Secure repository tile featuring file-type badges (PDF, XML, JSON), upload timestamps, and a digital signature validation status.