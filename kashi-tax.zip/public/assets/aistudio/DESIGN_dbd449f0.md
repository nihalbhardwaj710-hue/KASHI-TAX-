---
name: Vibrant Gamified Language System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3c4a42'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6c7a71'
  outline-variant: '#bbcabf'
  surface-tint: '#006c49'
  primary: '#006c49'
  on-primary: '#ffffff'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#4edea3'
  secondary: '#4b41e1'
  on-secondary: '#ffffff'
  secondary-container: '#645efb'
  on-secondary-container: '#fffbff'
  tertiary: '#855300'
  on-tertiary: '#ffffff'
  tertiary-container: '#e29100'
  on-tertiary-container: '#523200'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system pairs the delightful, high-dopamine momentum of gamified learning with the disciplined restraint, structural clarity, and tactile precision of modern Apple interface design. It avoids chaotic clutter in favor of crisp visual hierarchy, deliberate spatial breathing room, and deeply tactile interactions.

### Target Audience & Emotional Intent
- **Audience:** Motivated learners, polyglots, and daily habit builders who value both playful encouragement and a focused, adult aesthetic.
- **Tone:** Encouraging, punchy, intellectually rewarding, and crisp.
- **Design Style:** A synthesis of *Refined Tactile Flat* and *Contemporary Humanist Modernism*. Interface surfaces feel clean and planar, but actionable controls feature subtle structural depth (extruded button bases, crisp micro-borders, and soft dynamic physics) that make interactions feel physical and satisfying.

## Colors

The palette balances energetic reward hues with structured, high-legibility neutrals:

- **Primary (`#10B981` — Emerald Pulse):** Drives forward progress, streak validations, correct submissions, and main primary actions.
- **Secondary (`#4F46E5` — Deep Indigo):** Represents intellectual focus, skill tree milestones, grammar modules, and core navigation pillars.
- **Tertiary (`#F59E0B` — Solar Amber):** Reserved for achievements, streak counters, gem currencies, audio play triggers, and active booster states.
- **Neutral (`#0F172A` — Ink Slate):** Provides high-contrast clarity for typography, crisp micro-borders, and grounded canvas structure, preventing the UI from devolving into toy-like softness.

### Surface Color Logic
- **Canvas Base:** `#F8FAFC` (Slate Tint 50) for a crisp, low-glare backdrop.
- **Surface Cards:** `#FFFFFF` for primary exercise containers, flashcards, and navigation panels.
- **Elevated Interactive Base:** Tonal shifts 2–4% darker than active faces to create 3D click offsets rather than fuzzy blurred shadows.

## Typography

The type system is powered by **Plus Jakarta Sans**, offering a clean geometric baseline blended with humanist quirks, wide apertures, and exceptional legibility at quick glance speeds.

- **Display & Headlines:** Set in bold and extra-bold weights with tight negative tracking to deliver punchy lesson titles, level up banners, and streak announcements.
- **Body:** Kept at medium weights (`500`) for interactive sentence prompts, multiple-choice tokens, and phonetic guides to ensure crisp readability across varied screen densities.
- **Labels & Micro-copy:** Uppercase or tracking-spaced small labels provide structure for category badges, audio replay chips, and bottom bar navigation items.

## Layout & Spacing

The layout operates on an 8-point base rhythm optimized for handheld speed and vertical swipe feeds. 

- **Grid Architecture:** 
  - **Mobile (< 768px):** Single-column stacked fluid layout with `margin: 1rem` (16px) margins and tight `space-md` gaps.
  - **Tablet (768px – 1024px):** Centered modal viewports maxing out at 680px for lesson modes, allowing ergonomic dual-thumb tapping.
  - **Desktop (> 1024px):** Fixed-rail navigation (260px) paired with an 8-column exercise stage (`max-width: 1040px`), surrounded by expansive side margins.
- **Vertical Spacing:** Generous whitespace between lesson prompts and answer token trays eliminates accidental mis-taps while preserving vertical momentum.

## Elevation & Depth

Visual depth is achieved through tactile planar layering rather than heavy ambient blur:

- **Tactile Edge Depths:** Primary interaction targets feature a solid border bottom or extruded 3D base (3px to 4px) rendered in a darkened shade of the element’s fill color (e.g., `#059669` beneath `#10B981`). On press, the element translates down vertically by 2px to 3px to emulate a physical key press.
- **Resting Surface Cards:** Bordered by a crisp, low-contrast stroke (`#E2E8F0`, 1.5px) paired with an ultra-soft foundation shadow (`0 2px 4px rgba(15, 23, 42, 0.04)`).
- **Floating Heads-Up Displays (HUD):** Sticky top bars (displaying streaks, hearts, and gems) utilize semi-translucent frosted glass (`rgba(255, 255, 255, 0.85)` with `backdrop-filter: blur(12px)`) anchored with a crisp bottom divider.

## Shapes

The geometric personality balances friendly consumer ergonomics with deliberate structural polish:

- **Standard Cards & Input Modules:** Built with `rounded-lg` (16px / 1rem) corner radii, giving flashcards and multiple-choice cards an approachable, touch-friendly presence.
- **Action Buttons & Badges:** Use either full pill enclosures (9999px) for single-action prompts or `rounded-md` (8px / 0.5rem) for structured in-line grammatical chips.
- **Structural Panels:** Large modal sheets and bottom draw-ins utilize `rounded-xl` (24px / 1.5rem) on top surfaces.

## Components

### Buttons & Interactive Controls
- **Primary Action (Continue / Check):** Emerald green surface (`#10B981`), full width on mobile, 48px to 56px height, high-contrast white text (`label-lg`), with a 4px extruded bottom ridge (`#059669`). Depresses downward smoothly on `:active`.
- **Secondary (Skip / Reveal):** Ghost styling with an off-white background, 2px interior border in `#E2E8F0`, with a subtle slate press offset.
- **Audio Play Button:** Circular amber pill featuring an inset speaker icon, delivering micro-scale visual bounce when audio prompts stream.

### Selectable Answer Cards & Tokens
- **Default State:** White background, 2px border in `#E2E8F0`, with typography set in `title-md`.
- **Selected State:** Light indigo surface tint (`#EEF2FF`), solid `#4F46E5` border (2px), with subtle interior checkmark indication.
- **Evaluation States:**
  - *Correct:* Emerald wash (`#ECFDF5`), `#10B981` border, accompanied by a dynamic check icon.
  - *Incorrect:* Crimson wash (`#FEF2F2`), `#EF4444` border, accompanied by a gentle horizontal shake cue.

### Chips & Grammar Tags
- Compact, pill-shaped tags used for word banks and pronunciation guides. Set in `label-sm` with a light neutral base (`#F1F5F9`) and Slate text (`#334155`).

### Input Fields & Translation Blocks
- Generously padded (`space-md`), border-radius `rounded-lg`, border weight 2px `#CBD5E1`. Focus shifts border instantly to Indigo (`#4F46E5`) with an exterior 3px focus ring tinted at 15% opacity.

### Streak & Stat HUD
- Compact pill-shaped modules living in the upper interface band: fire icon paired with amber streak number, heart icon in vivid ruby, and emerald gem metrics, all set in bold tabular numerals.