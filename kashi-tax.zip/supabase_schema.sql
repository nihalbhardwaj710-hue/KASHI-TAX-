-- =====================================================================
-- Kashi Tax & Business Services — Supabase Database & Private Storage SQL
-- Run this script once in your Supabase Dashboard -> SQL Editor.
-- =====================================================================

-- 1. Customer Enquiries & Service Applications Table
create table if not exists public.enquiries (
  id uuid primary key default gen_random_uuid(),
  reference_code text not null unique,
  customer_name text not null,
  mobile_number text not null,
  service_category text not null,
  service_name text not null,
  message text not null default '',
  attached_documents text not null default '',
  payment_mode text not null default 'NONE',
  payment_proof text not null default '',
  status text not null default 'PENDING' check (status in ('PENDING', 'COMPLETED')),
  priority text not null default 'STANDARD' check (priority in ('STANDARD', 'URGENT')),
  created_at timestamptz not null default now()
);

create index if not exists idx_enquiries_created_at on public.enquiries (created_at desc);
create index if not exists idx_enquiries_status on public.enquiries (status);

alter table public.enquiries enable row level security;

drop policy if exists "Allow public customer enquiry submission" on public.enquiries;
create policy "Allow public customer enquiry submission"
  on public.enquiries
  for insert
  to anon, authenticated
  with check (
    char_length(customer_name) >= 2
    and char_length(mobile_number) = 10
    and status = 'PENDING'
  );

drop policy if exists "Allow authenticated admin to view enquiries" on public.enquiries;
create policy "Allow authenticated admin to view enquiries"
  on public.enquiries
  for select
  to authenticated
  using (true);

drop policy if exists "Allow authenticated admin to update enquiries" on public.enquiries;
create policy "Allow authenticated admin to update enquiries"
  on public.enquiries
  for update
  to authenticated
  using (true)
  with check (status in ('PENDING', 'COMPLETED'));

drop policy if exists "Allow authenticated admin to delete enquiries" on public.enquiries;
create policy "Allow authenticated admin to delete enquiries"
  on public.enquiries
  for delete
  to authenticated
  using (true);

-- =====================================================================
-- 2. Private Customer Document Vault Metadata Table
-- Each authenticated customer can ONLY read/insert/delete THEIR OWN rows.
-- =====================================================================
create table if not exists public.customer_documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  category text not null check (category in ('GST', 'ITR', 'PAN', 'Aadhaar', 'Other')),
  file_name text not null,
  storage_path text not null unique,
  mime_type text not null default 'application/octet-stream',
  file_size_bytes bigint not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_customer_documents_user_id on public.customer_documents (user_id, created_at desc);

alter table public.customer_documents enable row level security;

drop policy if exists "Customers can view own document records" on public.customer_documents;
create policy "Customers can view own document records"
  on public.customer_documents
  for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Customers can insert own document records" on public.customer_documents;
create policy "Customers can insert own document records"
  on public.customer_documents
  for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "Customers can delete own document records" on public.customer_documents;
create policy "Customers can delete own document records"
  on public.customer_documents
  for delete
  to authenticated
  using (auth.uid() = user_id);

-- =====================================================================
-- 3. Private Storage Bucket: `documents` (public = false)
-- Strict per-user folder isolation: {auth.uid()}/{category}/{file}
-- NO public / anon access is allowed.
-- =====================================================================
insert into storage.buckets (id, name, public)
values ('documents', 'documents', false)
on conflict (id) do update set public = false;

-- Remove any older public or overly broad policies on `documents`
drop policy if exists "Allow customers to upload documents" on storage.objects;
drop policy if exists "Allow authenticated admin to read documents" on storage.objects;
drop policy if exists "Customers upload only to own folder in documents" on storage.objects;
drop policy if exists "Customers read only own folder in documents" on storage.objects;
drop policy if exists "Customers update only own folder in documents" on storage.objects;
drop policy if exists "Customers delete only own folder in documents" on storage.objects;

create policy "Customers upload only to own folder in documents"
  on storage.objects
  for insert
  to authenticated
  with check (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "Customers read only own folder in documents"
  on storage.objects
  for select
  to authenticated
  using (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "Customers update only own folder in documents"
  on storage.objects
  for update
  to authenticated
  using (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  )
  with check (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "Customers delete only own folder in documents"
  on storage.objects
  for delete
  to authenticated
  using (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  );
